<?php
// الصفحة الرئيسية للموقع
// index.php

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/Database.php';

$db = Database::getInstance();

// جلب المباريات الجارية
$liveFixtures = $db->query(
    "SELECT * FROM fixtures WHERE is_live = 1 ORDER BY date ASC LIMIT 6"
);

// جلب مباريات اليوم
$todayFixtures = $db->query(
    "SELECT * FROM fixtures 
     WHERE DATE(date) = CURDATE() 
     ORDER BY date ASC 
     LIMIT 12"
);

// جلب أهم الدوريات
$topLeagues = $db->query(
    "SELECT DISTINCT league_id, league_name, league_logo, league_country 
     FROM fixtures 
     WHERE league_id IN (39, 140, 135, 78, 61, 2, 3)
     ORDER BY league_name 
     LIMIT 10"
);

// إحصائيات عامة
$stats = [
    'total_fixtures' => $db->count('fixtures'),
    'live_fixtures' => $db->count('fixtures', 'is_live = 1'),
    'today_fixtures' => $db->count('fixtures', 'DATE(date) = CURDATE()'),
    'total_leagues' => $db->count('leagues')
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - بث مباشر لجميع المباريات</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="شاهد جميع مباريات كرة القدم مباشرة مع Yacine TV - نتائج حية، جداول المباريات، الترتيب والإحصائيات">
    <meta name="keywords" content="كرة القدم, مباريات مباشرة, نتائج المباريات, الدوري الإنجليزي, الدوري الإسباني">
    
    <!-- Bootstrap RTL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            font-family: 'Cairo', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .hero-section {
            padding: 60px 0;
            color: white;
            text-align: center;
        }
        
        .hero-title {
            font-size: 3rem;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            margin-bottom: 20px;
        }
        
        .stats-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            transition: transform 0.3s;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .stats-card:hover {
            transform: translateY(-10px);
        }
        
        .stats-icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }
        
        .match-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .match-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 25px rgba(0,0,0,0.2);
        }
        
        .live-badge {
            background: #dc3545;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
        }
        
        .league-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .league-card:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        
        .section-title {
            color: white;
            font-weight: 700;
            margin: 40px 0 30px;
            text-align: center;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        
        .team-logo {
            width: 40px;
            height: 40px;
            object-fit: contain;
        }
        
        .footer {
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 40px 0;
            margin-top: 60px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-broadcast" style="font-size: 1.5rem; color: #667eea;"></i>
                <strong style="color: #667eea;"><?php echo SITE_NAME; ?></strong>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="/">
                            <i class="bi bi-house-fill"></i> الرئيسية
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/live">
                            <i class="bi bi-broadcast"></i> مباشر
                            <?php if ($stats['live_fixtures'] > 0): ?>
                                <span class="badge bg-danger"><?php echo $stats['live_fixtures']; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/today">
                            <i class="bi bi-calendar-event"></i> مباريات اليوم
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/login.php">
                            <i class="bi bi-shield-lock"></i> الإدارة
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1 class="hero-title">
                <i class="bi bi-trophy-fill"></i>
                مرحباً بك في <?php echo SITE_NAME; ?>
            </h1>
            <p class="lead">تابع جميع مباريات كرة القدم مباشرة مع النتائج والإحصائيات اللحظية</p>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="container">
        <div class="row g-4 mb-5">
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-broadcast text-danger stats-icon"></i>
                    <h3 class="text-danger"><?php echo $stats['live_fixtures']; ?></h3>
                    <p class="text-muted mb-0">مباراة جارية</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-calendar-check text-primary stats-icon"></i>
                    <h3 class="text-primary"><?php echo $stats['today_fixtures']; ?></h3>
                    <p class="text-muted mb-0">مباريات اليوم</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-trophy text-warning stats-icon"></i>
                    <h3 class="text-warning"><?php echo $stats['total_leagues']; ?></h3>
                    <p class="text-muted mb-0">دوري متاح</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="bi bi-controller text-success stats-icon"></i>
                    <h3 class="text-success"><?php echo number_format($stats['total_fixtures']); ?></h3>
                    <p class="text-muted mb-0">إجمالي المباريات</p>
                </div>
            </div>
        </div>
        
        <!-- Live Matches -->
        <?php if (!empty($liveFixtures)): ?>
        <h2 class="section-title">
            <i class="bi bi-broadcast"></i> المباريات الجارية الآن
        </h2>
        
        <div class="row">
            <?php foreach ($liveFixtures as $fixture): ?>
            <div class="col-md-6">
                <div class="match-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <img src="<?php echo $fixture['league_logo']; ?>" width="25" alt="">
                            <small class="ms-2"><?php echo $fixture['league_name']; ?></small>
                        </div>
                        <span class="live-badge">
                            <i class="bi bi-circle-fill"></i> LIVE
                        </span>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="text-center flex-fill">
                            <img src="<?php echo $fixture['home_team_logo']; ?>" class="team-logo mb-2" alt="">
                            <div><strong><?php echo $fixture['home_team_name']; ?></strong></div>
                        </div>
                        
                        <div class="text-center px-4">
                            <h2 class="mb-0 text-primary">
                                <?php echo $fixture['goals_home'] ?? 0; ?> - <?php echo $fixture['goals_away'] ?? 0; ?>
                            </h2>
                            <small class="text-muted"><?php echo $fixture['status_elapsed']; ?>'</small>
                        </div>
                        
                        <div class="text-center flex-fill">
                            <img src="<?php echo $fixture['away_team_logo']; ?>" class="team-logo mb-2" alt="">
                            <div><strong><?php echo $fixture['away_team_name']; ?></strong></div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-3">
                        <a href="/match/<?php echo $fixture['api_id']; ?>" class="btn btn-sm btn-primary">
                            <i class="bi bi-eye"></i> التفاصيل
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <!-- Today's Matches -->
        <?php if (!empty($todayFixtures)): ?>
        <h2 class="section-title">
            <i class="bi bi-calendar-event"></i> مباريات اليوم
        </h2>
        
        <div class="row">
            <?php foreach ($todayFixtures as $fixture): ?>
            <div class="col-md-4">
                <div class="match-card">
                    <div class="text-center mb-3">
                        <img src="<?php echo $fixture['league_logo']; ?>" width="25" alt="">
                        <small class="ms-2"><?php echo $fixture['league_name']; ?></small>
                    </div>
                    
                    <div class="text-center mb-3">
                        <div class="d-flex justify-content-around align-items-center">
                            <div>
                                <img src="<?php echo $fixture['home_team_logo']; ?>" width="35" alt="">
                                <div class="mt-2"><small><?php echo $fixture['home_team_name']; ?></small></div>
                            </div>
                            
                            <div>
                                <?php if ($fixture['goals_home'] !== null): ?>
                                    <h4 class="mb-0"><?php echo $fixture['goals_home']; ?> - <?php echo $fixture['goals_away']; ?></h4>
                                <?php else: ?>
                                    <div class="text-muted">
                                        <small><?php echo date('H:i', strtotime($fixture['date'])); ?></small>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div>
                                <img src="<?php echo $fixture['away_team_logo']; ?>" width="35" alt="">
                                <div class="mt-2"><small><?php echo $fixture['away_team_name']; ?></small></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center">
                        <span class="badge bg-secondary"><?php echo getMatchStatusAr($fixture['status_short']); ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <!-- Top Leagues -->
        <?php if (!empty($topLeagues)): ?>
        <h2 class="section-title">
            <i class="bi bi-trophy"></i> أهم الدوريات
        </h2>
        
        <div class="row g-3 mb-5">
            <?php foreach ($topLeagues as $league): ?>
            <div class="col-md-3 col-sm-6">
                <a href="/league/<?php echo $league['league_id']; ?>" class="text-decoration-none">
                    <div class="league-card">
                        <img src="<?php echo $league['league_logo']; ?>" width="50" class="mb-2" alt="">
                        <h6 class="mb-1"><?php echo $league['league_name']; ?></h6>
                        <small class="text-muted"><?php echo $league['league_country']; ?></small>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><i class="bi bi-broadcast"></i> <?php echo SITE_NAME; ?></h5>
                    <p>أفضل موقع لمتابعة مباريات كرة القدم مباشرة مع النتائج والإحصائيات اللحظية</p>
                </div>
                <div class="col-md-4">
                    <h5>روابط سريعة</h5>
                    <ul class="list-unstyled">
                        <li><a href="/live" class="text-white text-decoration-none">المباريات الجارية</a></li>
                        <li><a href="/today" class="text-white text-decoration-none">مباريات اليوم</a></li>
                        <li><a href="<?php echo ADMIN_PATH; ?>" class="text-white text-decoration-none">لوحة التحكم</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>تواصل معنا</h5>
                    <p>
                        <i class="bi bi-globe"></i> <?php echo SITE_URL; ?><br>
                        <i class="bi bi-envelope"></i> info@yacine--tv.live
                    </p>
                </div>
            </div>
            <hr class="bg-white">
            <div class="text-center">
                <p class="mb-0">© <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - جميع الحقوق محفوظة</p>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Auto Refresh for Live Matches -->
    <script>
        // تحديث تلقائي للمباريات الجارية كل 30 ثانية
        <?php if (!empty($liveFixtures)): ?>
        setInterval(() => {
            location.reload();
        }, 30000);
        <?php endif; ?>
    </script>
</body>
</html>