<?php
// تتبع استهلاك طلبات API
// classes/ApiUsageTracker.php

require_once __DIR__ . '/../config/Database.php';

class ApiUsageTracker {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    // تسجيل طلب API
    public function logRequest($endpoint, $success = true, $responseSize = 0) {
        $today = date('Y-m-d');
        
        // التحقق من وجود سجل اليوم
        $record = $this->db->queryOne(
            "SELECT * FROM api_usage WHERE date = :date",
            ['date' => $today]
        );
        
        if ($record) {
            // تحديث السجل الموجود
            $this->db->execute(
                "UPDATE api_usage SET 
                 total_requests = total_requests + 1,
                 successful_requests = successful_requests + :success,
                 failed_requests = failed_requests + :failed,
                 total_data_size = total_data_size + :size,
                 last_request_time = NOW()
                 WHERE date = :date",
                [
                    'success' => $success ? 1 : 0,
                    'failed' => $success ? 0 : 1,
                    'size' => $responseSize,
                    'date' => $today
                ]
            );
        } else {
            // إنشاء سجل جديد
            $this->db->insert('api_usage', [
                'date' => $today,
                'total_requests' => 1,
                'successful_requests' => $success ? 1 : 0,
                'failed_requests' => $success ? 0 : 1,
                'total_data_size' => $responseSize,
                'last_request_time' => date('Y-m-d H:i:s')
            ]);
        }
        
        // تسجيل تفاصيل الطلب
        $this->db->insert('api_request_details', [
            'date' => $today,
            'endpoint' => $endpoint,
            'success' => $success ? 1 : 0,
            'response_size' => $responseSize,
            'request_time' => date('Y-m-d H:i:s')
        ]);
    }
    
    // الحصول على إحصائيات اليوم
    public function getTodayUsage() {
        $today = date('Y-m-d');
        $usage = $this->db->queryOne(
            "SELECT * FROM api_usage WHERE date = :date",
            ['date' => $today]
        );
        
        if (!$usage) {
            return [
                'total_requests' => 0,
                'successful_requests' => 0,
                'failed_requests' => 0,
                'total_data_size' => 0,
                'last_request_time' => null
            ];
        }
        
        return $usage;
    }
    
    // الحصول على إحصائيات الشهر
    public function getMonthUsage() {
        $month = date('Y-m');
        $usage = $this->db->queryOne(
            "SELECT 
             SUM(total_requests) as total_requests,
             SUM(successful_requests) as successful_requests,
             SUM(failed_requests) as failed_requests,
             SUM(total_data_size) as total_data_size
             FROM api_usage 
             WHERE DATE_FORMAT(date, '%Y-%m') = :month",
            ['month' => $month]
        );
        
        return $usage ?: [
            'total_requests' => 0,
            'successful_requests' => 0,
            'failed_requests' => 0,
            'total_data_size' => 0
        ];
    }
    
    // الحصول على إحصائيات آخر 7 أيام
    public function getWeekUsage() {
        return $this->db->query(
            "SELECT * FROM api_usage 
             WHERE date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
             ORDER BY date DESC"
        );
    }
    
    // الحصول على أكثر Endpoints استخداماً
    public function getTopEndpoints($limit = 10) {
        return $this->db->query(
            "SELECT 
             endpoint,
             COUNT(*) as count,
             SUM(success) as successful,
             SUM(CASE WHEN success = 0 THEN 1 ELSE 0 END) as failed
             FROM api_request_details 
             WHERE date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
             GROUP BY endpoint 
             ORDER BY count DESC 
             LIMIT :limit",
            ['limit' => $limit]
        );
    }
    
    // تنظيف السجلات القديمة (أكثر من 90 يوم)
    public function cleanOldRecords() {
        $this->db->execute(
            "DELETE FROM api_usage WHERE date < DATE_SUB(CURDATE(), INTERVAL 90 DAY)"
        );
        $this->db->execute(
            "DELETE FROM api_request_details WHERE date < DATE_SUB(CURDATE(), INTERVAL 90 DAY)"
        );
    }
    
    // تحويل حجم البيانات إلى صيغة قابلة للقراءة
    public static function formatBytes($bytes) {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' Bytes';
        }
    }
    
    // حساب النسبة المئوية من الحد اليومي
    public function getUsagePercentage($dailyLimit = 100) {
        $today = $this->getTodayUsage();
        $percentage = ($today['total_requests'] / $dailyLimit) * 100;
        return min(100, $percentage);
    }
}