<?php
// المجدول الذكي للتحديثات التلقائية
// classes/Scheduler.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/ApiFootball.php';

class Scheduler {
    private $db;
    private $api;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->api = new ApiFootball();
    }
    
    // التحقق من جميع التحديثات المطلوبة
    public function checkAllUpdates() {
        $updates = $this->db->query("SELECT * FROM system_updates");
        $results = [];
        
        foreach ($updates as $update) {
            if ($this->shouldUpdate($update)) {
                $results[$update['update_type']] = $this->executeUpdate($update['update_type']);
            }
        }
        
        return $results;
    }
    
    // التحقق من حاجة التحديث
    private function shouldUpdate($update) {
        $lastUpdate = strtotime($update['last_update']);
        $now = time();
        $interval = $update['update_interval'];
        
        return ($now - $lastUpdate) >= $interval;
    }
    
    // تنفيذ التحديث حسب النوع
    private function executeUpdate($type) {
        try {
            switch ($type) {
                case 'daily_fixtures':
                    return $this->updateDailyFixtures();
                    
                case 'live_fixtures':
                    return $this->updateLiveFixtures();
                    
                case 'fixtures_statistics':
                    return $this->updateFixturesStatistics();
                    
                case 'fixtures_events':
                    return $this->updateFixturesEvents();
                    
                case 'fixtures_lineups':
                    return $this->updateFixturesLineups();
                    
                case 'leagues_standings':
                    return $this->updateLeaguesStandings();
                    
                case 'leagues_scorers':
                    return $this->updateLeaguesScorers();
                    
                case 'teams_data':
                    return $this->updateTeamsData();
                    
                case 'players_data':
                    return $this->updatePlayersData();
                    
                default:
                    return ['success' => false, 'message' => 'نوع تحديث غير معروف'];
            }
        } catch (Exception $e) {
            $this->logError($type, $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // تحديث مباريات اليوم
    private function updateDailyFixtures() {
        $today = date('Y-m-d');
        $result = $this->api->getDailyFixtures($today);
        
        return [
            'success' => $result['success'],
            'message' => $result['success'] ? "تم جلب {$result['count']} مباراة" : $result['error'],
            'count' => $result['count'] ?? 0
        ];
    }
    
    // تحديث المباريات الجارية
    private function updateLiveFixtures() {
        $result = $this->api->getLiveFixtures();
        
        return [
            'success' => $result['success'],
            'message' => $result['success'] ? "تم تحديث {$result['count']} مباراة جارية" : $result['error'],
            'count' => $result['count'] ?? 0
        ];
    }
    
    // تحديث إحصائيات المباريات الجارية
    private function updateFixturesStatistics() {
        $liveFixtures = $this->db->query(
            "SELECT api_id FROM fixtures WHERE is_live = 1"
        );
        
        $count = 0;
        foreach ($liveFixtures as $fixture) {
            $result = $this->api->getFixtureStatistics($fixture['api_id']);
            if ($result['success']) {
                $count++;
            }
        }
        
        return [
            'success' => true,
            'message' => "تم تحديث إحصائيات {$count} مباراة",
            'count' => $count
        ];
    }
    
    // تحديث أحداث المباريات الجارية
    private function updateFixturesEvents() {
        $liveFixtures = $this->db->query(
            "SELECT api_id FROM fixtures WHERE is_live = 1"
        );
        
        $count = 0;
        foreach ($liveFixtures as $fixture) {
            $result = $this->api->getFixtureEvents($fixture['api_id']);
            if ($result['success']) {
                $count++;
            }
        }
        
        return [
            'success' => true,
            'message' => "تم تحديث أحداث {$count} مباراة",
            'count' => $count
        ];
    }
    
    // تحديث تشكيلات المباريات القادمة
    private function updateFixturesLineups() {
        // جلب المباريات التي ستبدأ خلال 30 دقيقة
        $time = date('Y-m-d H:i:s', strtotime('+30 minutes'));
        
        $fixtures = $this->db->query(
            "SELECT api_id FROM fixtures 
             WHERE date <= :time 
             AND status_short = 'NS' 
             AND api_id NOT IN (SELECT fixture_id FROM lineups)",
            ['time' => $time]
        );
        
        $count = 0;
        foreach ($fixtures as $fixture) {
            $result = $this->api->getFixtureLineups($fixture['api_id']);
            if ($result['success']) {
                $count++;
            }
        }
        
        return [
            'success' => true,
            'message' => "تم تحديث تشكيلات {$count} مباراة",
            'count' => $count
        ];
    }
    
    // تحديث ترتيب الدوريات
    private function updateLeaguesStandings() {
        $leagues = $this->db->query(
            "SELECT DISTINCT league_id, league_season 
             FROM fixtures 
             WHERE league_season = YEAR(CURDATE())
             LIMIT 10"
        );
        
        $count = 0;
        foreach ($leagues as $league) {
            $result = $this->api->getStandings($league['league_id'], $league['league_season']);
            if ($result['success']) {
                $count++;
            }
        }
        
        return [
            'success' => true,
            'message' => "تم تحديث ترتيب {$count} دوري",
            'count' => $count
        ];
    }
    
    // تحديث الهدافين
    private function updateLeaguesScorers() {
        $leagues = $this->db->query(
            "SELECT DISTINCT league_id, league_season 
             FROM fixtures 
             WHERE league_season = YEAR(CURDATE())
             LIMIT 10"
        );
        
        $count = 0;
        foreach ($leagues as $league) {
            $result = $this->api->getTopScorers($league['league_id'], $league['league_season']);
            if ($result['success']) {
                $count++;
            }
        }
        
        return [
            'success' => true,
            'message' => "تم تحديث هدافين {$count} دوري",
            'count' => $count
        ];
    }
    
    // تحديث بيانات الفرق
    private function updateTeamsData() {
        $result = $this->api->getTeams();
        
        return [
            'success' => $result['success'],
            'message' => $result['success'] ? "تم تحديث {$result['count']} فريق" : $result['error'],
            'count' => $result['count'] ?? 0
        ];
    }
    
    // تحديث بيانات اللاعبين
    private function updatePlayersData() {
        // يمكن إضافة منطق جلب اللاعبين هنا
        return [
            'success' => true,
            'message' => "تحديث اللاعبين غير متاح حالياً",
            'count' => 0
        ];
    }
    
    // تسجيل الأخطاء
    private function logError($type, $message) {
        $this->db->update(
            'system_updates',
            [
                'status' => 'failed',
                'error_message' => $message
            ],
            'update_type = :type',
            ['type' => $type]
        );
        
        $this->db->insert('logs', [
            'action_type' => 'scheduler_error',
            'action_description' => "Error in {$type}: {$message}",
            'status' => 'failed'
        ]);
    }
    
    // تنفيذ تحديث محدد يدوياً
    public function runManualUpdate($type) {
        return $this->executeUpdate($type);
    }
    
    // جلب جميع البيانات الأساسية (للاستخدام الأولي - الدوريات المحددة فقط)
    public function initialDataFetch() {
        $results = [];
        
        // 1. جلب الدوريات المحددة فقط
        $results['leagues'] = $this->api->getSelectedLeagues();
        
        // 2. جلب مباريات اليوم (تلقائياً من الدوريات المحددة)
        $results['daily_fixtures'] = $this->updateDailyFixtures();
        
        // 3. جلب المباريات الجارية (تلقائياً من الدوريات المحددة)
        $results['live_fixtures'] = $this->updateLiveFixtures();
        
        // 4. جلب الفرق من الدوريات المحددة
        $results['teams'] = $this->api->getTeamsFromSelectedLeagues();
        
        // 5. جلب الترتيب والهدافين للدوريات المحددة
        $standingsScorers = $this->api->getStandingsAndScorersForSelected();
        $results['standings'] = ['success' => true, 'count' => $standingsScorers['standings_count']];
        $results['scorers'] = ['success' => true, 'count' => $standingsScorers['scorers_count']];
        
        return $results;
    }
    
    // الحصول على حالة التحديثات
    public function getUpdateStatus() {
        return $this->db->query(
            "SELECT update_type, last_update, status, records_count, error_message 
             FROM system_updates 
             ORDER BY last_update DESC"
        );
    }
}