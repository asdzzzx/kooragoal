<?php
// كلاس التعامل مع API-FOOTBALL (معدل للدوريات المحددة)
// classes/ApiFootball.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../config/leagues_config.php';
require_once __DIR__ . '/ApiUsageTracker.php';

class ApiFootball {
    private $apiKey;
    private $apiHost;
    private $apiBaseUrl;
    private $db;
    private $usageTracker;
    
    public function __construct() {
        $this->apiKey = API_KEY;
        $this->apiHost = API_HOST;
        $this->apiBaseUrl = API_BASE_URL;
        $this->db = Database::getInstance();
        $this->usageTracker = new ApiUsageTracker();
    }
    
    // دالة عامة لطلبات API
    private function makeRequest($endpoint, $params = []) {
        $url = $this->apiBaseUrl . $endpoint;
        
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_HTTPHEADER => [
                "x-rapidapi-host: " . $this->apiHost,
                "x-rapidapi-key: " . $this->apiKey
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        $responseSize = strlen($response);
        
        curl_close($ch);
        
        if ($error) {
            $this->logApiCall($endpoint, 'failed', 0, $error);
            $this->usageTracker->logRequest($endpoint, false, $responseSize);
            return ['success' => false, 'error' => $error];
        }
        
        if ($httpCode !== 200) {
            $this->logApiCall($endpoint, 'failed', 0, "HTTP Code: {$httpCode}");
            $this->usageTracker->logRequest($endpoint, false, $responseSize);
            return ['success' => false, 'error' => "HTTP Error: {$httpCode}"];
        }
        
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logApiCall($endpoint, 'failed', 0, 'JSON Decode Error');
            $this->usageTracker->logRequest($endpoint, false, $responseSize);
            return ['success' => false, 'error' => 'Invalid JSON response'];
        }
        
        if (!isset($data['response'])) {
            $this->logApiCall($endpoint, 'failed', 0, 'No response data');
            $this->usageTracker->logRequest($endpoint, false, $responseSize);
            return ['success' => false, 'error' => 'No response data'];
        }
        
        $count = is_array($data['response']) ? count($data['response']) : 0;
        $this->logApiCall($endpoint, 'success', $count);
        $this->usageTracker->logRequest($endpoint, true, $responseSize);
        
        return [
            'success' => true,
            'data' => $data['response'],
            'count' => $count
        ];
    }
    
    // سجل طلبات API
    private function logApiCall($endpoint, $status, $count, $error = null) {
        $this->db->insert('logs', [
            'action_type' => 'api_call',
            'action_description' => $endpoint . ($error ? " - Error: $error" : ''),
            'status' => $status,
            'ip_address' => $count . ' records'
        ]);
    }
    
    // جلب مباريات اليوم (للدوريات المحددة فقط)
    public function getDailyFixtures($date = null) {
        if (!$date) {
            $date = date('Y-m-d');
        }
        
        $result = $this->makeRequest('/fixtures', ['date' => $date]);
        
        if ($result['success']) {
            // فلترة المباريات للدوريات المحددة فقط
            $filtered = array_filter($result['data'], function($fixture) {
                return isSelectedLeague($fixture['league']['id']);
            });
            
            $this->saveDailyFixtures($filtered);
            $this->updateSystemUpdate('daily_fixtures', count($filtered));
            
            return ['success' => true, 'count' => count($filtered), 'data' => $filtered];
        }
        
        return $result;
    }
    
    // جلب المباريات الجارية (للدوريات المحددة فقط)
    public function getLiveFixtures() {
        $result = $this->makeRequest('/fixtures', ['live' => 'all']);
        
        if ($result['success']) {
            // فلترة المباريات للدوريات المحددة فقط
            $filtered = array_filter($result['data'], function($fixture) {
                return isSelectedLeague($fixture['league']['id']);
            });
            
            $this->updateLiveFixtures($filtered);
            $this->updateSystemUpdate('live_fixtures', count($filtered));
            
            return ['success' => true, 'count' => count($filtered), 'data' => $filtered];
        }
        
        return $result;
    }
    
    // جلب الدوريات المحددة فقط
    public function getSelectedLeagues() {
        $selectedIds = getSelectedLeagueIds();
        $allLeagues = [];
        $totalCount = 0;
        
        // جلب معلومات كل دوري محدد
        foreach ($selectedIds as $leagueId) {
            $result = $this->makeRequest('/leagues', ['id' => $leagueId]);
            
            if ($result['success'] && !empty($result['data'])) {
                $allLeagues = array_merge($allLeagues, $result['data']);
                $totalCount += count($result['data']);
            }
            
            // تأخير بسيط لتجنب تجاوز حد الطلبات
            usleep(100000); // 0.1 ثانية
        }
        
        if (!empty($allLeagues)) {
            $this->saveLeagues($allLeagues);
            return ['success' => true, 'count' => $totalCount, 'data' => $allLeagues];
        }
        
        return ['success' => false, 'error' => 'لم يتم جلب أي دوريات'];
    }
    
    // جلب الفرق من الدوريات المحددة فقط
    public function getTeamsFromSelectedLeagues() {
        $selectedIds = getSelectedLeagueIds();
        $allTeams = [];
        $totalCount = 0;
        $currentSeason = date('Y');
        
        // جلب فرق أول 20 دوري (لتجنب استهلاك كبير)
        $priorityLeagues = array_slice($selectedIds, 0, 20);
        
        foreach ($priorityLeagues as $leagueId) {
            $result = $this->makeRequest('/teams', [
                'league' => $leagueId,
                'season' => $currentSeason
            ]);
            
            if ($result['success'] && !empty($result['data'])) {
                $allTeams = array_merge($allTeams, $result['data']);
                $totalCount += count($result['data']);
            }
            
            usleep(200000); // 0.2 ثانية تأخير
        }
        
        if (!empty($allTeams)) {
            $this->saveTeams($allTeams);
            $this->updateSystemUpdate('teams_data', $totalCount);
            return ['success' => true, 'count' => $totalCount, 'data' => $allTeams];
        }
        
        return ['success' => false, 'error' => 'لم يتم جلب أي فرق'];
    }
    
    // جلب الترتيب والهدافين للدوريات المحددة
    public function getStandingsAndScorersForSelected() {
        $selectedIds = getSelectedLeagueIds();
        $currentSeason = date('Y');
        $results = ['standings' => 0, 'scorers' => 0];
        
        // الدوريات ذات الأولوية (أول 15 دوري)
        $priorityLeagues = array_slice($selectedIds, 0, 15);
        
        foreach ($priorityLeagues as $leagueId) {
            // جلب الترتيب
            $standings = $this->getStandings($leagueId, $currentSeason);
            if ($standings['success']) {
                $results['standings']++;
            }
            
            usleep(150000); // 0.15 ثانية
            
            // جلب الهدافين
            $scorers = $this->getTopScorers($leagueId, $currentSeason);
            if ($scorers['success']) {
                $results['scorers']++;
            }
            
            usleep(150000); // 0.15 ثانية
        }
        
        return [
            'success' => true,
            'standings_count' => $results['standings'],
            'scorers_count' => $results['scorers']
        ];
    }
    
    // باقي الدوال كما هي (نفس الكود السابق)
    public function getFixtureStatistics($fixtureId) {
        $result = $this->makeRequest('/fixtures/statistics', ['fixture' => $fixtureId]);
        
        if ($result['success']) {
            $this->saveFixtureStatistics($fixtureId, $result['data']);
        }
        
        return $result;
    }
    
    public function getFixtureEvents($fixtureId) {
        $result = $this->makeRequest('/fixtures/events', ['fixture' => $fixtureId]);
        
        if ($result['success']) {
            $this->saveFixtureEvents($fixtureId, $result['data']);
        }
        
        return $result;
    }
    
    public function getFixtureLineups($fixtureId) {
        $result = $this->makeRequest('/fixtures/lineups', ['fixture' => $fixtureId]);
        
        if ($result['success']) {
            $this->saveFixtureLineups($fixtureId, $result['data']);
            $this->updateSystemUpdate('fixtures_lineups', $result['count']);
        }
        
        return $result;
    }
    
    public function getStandings($leagueId, $season) {
        $result = $this->makeRequest('/standings', [
            'league' => $leagueId,
            'season' => $season
        ]);
        
        if ($result['success']) {
            $this->saveStandings($leagueId, $season, $result['data']);
            $this->updateSystemUpdate('leagues_standings', $result['count']);
        }
        
        return $result;
    }
    
    public function getTopScorers($leagueId, $season) {
        $result = $this->makeRequest('/players/topscorers', [
            'league' => $leagueId,
            'season' => $season
        ]);
        
        if ($result['success']) {
            $this->saveTopScorers($leagueId, $season, $result['data']);
            $this->updateSystemUpdate('leagues_scorers', $result['count']);
        }
        
        return $result;
    }
    
    public function getTeams($leagueId = null, $season = null) {
        $params = [];
        if ($leagueId) $params['league'] = $leagueId;
        if ($season) $params['season'] = $season;
        
        $result = $this->makeRequest('/teams', $params);
        
        if ($result['success']) {
            $this->saveTeams($result['data']);
            $this->updateSystemUpdate('teams_data', $result['count']);
        }
        
        return $result;
    }
    
    // حفظ المباريات (نفس الكود السابق)
    private function saveDailyFixtures($fixtures) {
        foreach ($fixtures as $fixture) {
            $data = [
                'api_id' => $fixture['fixture']['id'],
                'referee' => $fixture['fixture']['referee'] ?? null,
                'timezone' => $fixture['fixture']['timezone'] ?? 'UTC',
                'date' => date('Y-m-d H:i:s', $fixture['fixture']['timestamp']),
                'timestamp' => $fixture['fixture']['timestamp'],
                'venue_id' => $fixture['fixture']['venue']['id'] ?? null,
                'venue_name' => $fixture['fixture']['venue']['name'] ?? null,
                'venue_city' => $fixture['fixture']['venue']['city'] ?? null,
                'status_long' => $fixture['fixture']['status']['long'] ?? null,
                'status_short' => $fixture['fixture']['status']['short'] ?? null,
                'status_elapsed' => $fixture['fixture']['status']['elapsed'] ?? null,
                'league_id' => $fixture['league']['id'],
                'league_name' => $fixture['league']['name'] ?? null,
                'league_country' => $fixture['league']['country'] ?? null,
                'league_logo' => $fixture['league']['logo'] ?? null,
                'league_flag' => $fixture['league']['flag'] ?? null,
                'league_season' => $fixture['league']['season'] ?? null,
                'league_round' => $fixture['league']['round'] ?? null,
                'home_team_id' => $fixture['teams']['home']['id'],
                'home_team_name' => $fixture['teams']['home']['name'] ?? null,
                'home_team_logo' => $fixture['teams']['home']['logo'] ?? null,
                'home_team_winner' => $fixture['teams']['home']['winner'] ?? null,
                'away_team_id' => $fixture['teams']['away']['id'],
                'away_team_name' => $fixture['teams']['away']['name'] ?? null,
                'away_team_logo' => $fixture['teams']['away']['logo'] ?? null,
                'away_team_winner' => $fixture['teams']['away']['winner'] ?? null,
                'goals_home' => $fixture['goals']['home'] ?? null,
                'goals_away' => $fixture['goals']['away'] ?? null,
                'score_halftime_home' => $fixture['score']['halftime']['home'] ?? null,
                'score_halftime_away' => $fixture['score']['halftime']['away'] ?? null,
                'score_fulltime_home' => $fixture['score']['fulltime']['home'] ?? null,
                'score_fulltime_away' => $fixture['score']['fulltime']['away'] ?? null,
                'score_extratime_home' => $fixture['score']['extratime']['home'] ?? null,
                'score_extratime_away' => $fixture['score']['extratime']['away'] ?? null,
                'score_penalty_home' => $fixture['score']['penalty']['home'] ?? null,
                'score_penalty_away' => $fixture['score']['penalty']['away'] ?? null,
                'is_live' => in_array($fixture['fixture']['status']['short'], ['1H', '2H', 'ET', 'HT']) ? 1 : 0
            ];
            
            $exists = $this->db->exists('fixtures', 'api_id = :api_id', ['api_id' => $data['api_id']]);
            
            if ($exists) {
                unset($data['api_id']);
                $this->db->update('fixtures', $data, 'api_id = :api_id', ['api_id' => $fixture['fixture']['id']]);
            } else {
                $this->db->insert('fixtures', $data);
            }
        }
    }
    
    private function updateLiveFixtures($fixtures) {
        $this->db->execute("UPDATE fixtures SET is_live = 0");
        $this->saveDailyFixtures($fixtures);
    }
    
    // باقي الدوال الخاصة بالحفظ (نفس الكود السابق - saveFixtureStatistics, saveFixtureEvents, إلخ...)
    // (تم حذفها للاختصار - استخدم نفس الكود من الملف السابق)
    
    private function saveFixtureStatistics($fixtureId, $statistics) {
        foreach ($statistics as $stat) {
            $team = $stat['team'];
            $stats = $stat['statistics'];
            
            $data = [
                'fixture_id' => $fixtureId,
                'team_id' => $team['id'],
                'team_name' => $team['name'],
                'team_logo' => $team['logo']
            ];
            
            foreach ($stats as $s) {
                $type = $s['type'];
                $value = $s['value'];
                
                switch ($type) {
                    case 'Shots on Goal': $data['shots_on_goal'] = $value ?? 0; break;
                    case 'Shots off Goal': $data['shots_off_goal'] = $value ?? 0; break;
                    case 'Total Shots': $data['total_shots'] = $value ?? 0; break;
                    case 'Blocked Shots': $data['blocked_shots'] = $value ?? 0; break;
                    case 'Shots insidebox': $data['shots_inside_box'] = $value ?? 0; break;
                    case 'Shots outsidebox': $data['shots_outside_box'] = $value ?? 0; break;
                    case 'Fouls': $data['fouls'] = $value ?? 0; break;
                    case 'Corner Kicks': $data['corner_kicks'] = $value ?? 0; break;
                    case 'Offsides': $data['offsides'] = $value ?? 0; break;
                    case 'Ball Possession': $data['ball_possession'] = $value ?? '0%'; break;
                    case 'Yellow Cards': $data['yellow_cards'] = $value ?? 0; break;
                    case 'Red Cards': $data['red_cards'] = $value ?? 0; break;
                    case 'Goalkeeper Saves': $data['goalkeeper_saves'] = $value ?? 0; break;
                    case 'Total passes': $data['total_passes'] = $value ?? 0; break;
                    case 'Passes accurate': $data['passes_accurate'] = $value ?? 0; break;
                    case 'Passes %': $data['passes_percentage'] = $value ?? '0%'; break;
                    case 'expected_goals': $data['expected_goals'] = $value ?? '0.0'; break;
                }
            }
            
            $exists = $this->db->exists('statistics', 'fixture_id = :fixture_id AND team_id = :team_id',
                ['fixture_id' => $fixtureId, 'team_id' => $team['id']]);
            
            if ($exists) {
                $this->db->update('statistics', $data, 'fixture_id = :fixture_id AND team_id = :team_id',
                    ['fixture_id' => $fixtureId, 'team_id' => $team['id']]);
            } else {
                $this->db->insert('statistics', $data);
            }
        }
    }
    
    private function saveFixtureEvents($fixtureId, $events) {
        $this->db->delete('events', 'fixture_id = :fixture_id', ['fixture_id' => $fixtureId]);
        
        foreach ($events as $event) {
            $data = [
                'fixture_id' => $fixtureId,
                'time_elapsed' => $event['time']['elapsed'] ?? null,
                'time_extra' => $event['time']['extra'] ?? null,
                'team_id' => $event['team']['id'] ?? null,
                'team_name' => $event['team']['name'] ?? null,
                'team_logo' => $event['team']['logo'] ?? null,
                'player_id' => $event['player']['id'] ?? null,
                'player_name' => $event['player']['name'] ?? null,
                'assist_id' => $event['assist']['id'] ?? null,
                'assist_name' => $event['assist']['name'] ?? null,
                'type' => $event['type'] ?? null,
                'detail' => $event['detail'] ?? null,
                'comments' => $event['comments'] ?? null
            ];
            
            $this->db->insert('events', $data);
        }
    }
    
    private function saveFixtureLineups($fixtureId, $lineups) {
        foreach ($lineups as $lineup) {
            $data = [
                'fixture_id' => $fixtureId,
                'team_id' => $lineup['team']['id'],
                'team_name' => $lineup['team']['name'],
                'team_logo' => $lineup['team']['logo'],
                'formation' => $lineup['formation'] ?? null,
                'coach_id' => $lineup['coach']['id'] ?? null,
                'coach_name' => $lineup['coach']['name'] ?? null,
                'coach_photo' => $lineup['coach']['photo'] ?? null,
                'players' => json_encode($lineup['startXI'] ?? [], JSON_UNESCAPED_UNICODE),
                'substitutes' => json_encode($lineup['substitutes'] ?? [], JSON_UNESCAPED_UNICODE)
            ];
            
            $exists = $this->db->exists('lineups', 'fixture_id = :fixture_id AND team_id = :team_id',
                ['fixture_id' => $fixtureId, 'team_id' => $lineup['team']['id']]);
            
            if ($exists) {
                $this->db->update('lineups', $data, 'fixture_id = :fixture_id AND team_id = :team_id',
                    ['fixture_id' => $fixtureId, 'team_id' => $lineup['team']['id']]);
            } else {
                $this->db->insert('lineups', $data);
            }
        }
    }
    
    private function saveStandings($leagueId, $season, $standings) {
        foreach ($standings as $standing) {
            $league = $standing['league'];
            
            foreach ($league['standings'] as $group) {
                foreach ($group as $team) {
                    $data = [
                        'league_id' => $leagueId,
                        'season' => $season,
                        'team_id' => $team['team']['id'],
                        'team_name' => $team['team']['name'],
                        'team_logo' => $team['team']['logo'],
                        'rank' => $team['rank'],
                        'points' => $team['points'],
                        'goals_diff' => $team['goalsDiff'],
                        'group' => $team['group'] ?? null,
                        'form' => $team['form'] ?? null,
                        'status' => $team['status'] ?? null,
                        'description' => $team['description'] ?? null,
                        'played' => $team['all']['played'],
                        'win' => $team['all']['win'],
                        'draw' => $team['all']['draw'],
                        'lose' => $team['all']['lose'],
                        'goals_for' => $team['all']['goals']['for'],
                        'goals_against' => $team['all']['goals']['against'],
                        'home_played' => $team['home']['played'],
                        'home_win' => $team['home']['win'],
                        'home_draw' => $team['home']['draw'],
                        'home_lose' => $team['home']['lose'],
                        'home_goals_for' => $team['home']['goals']['for'],
                        'home_goals_against' => $team['home']['goals']['against'],
                        'away_played' => $team['away']['played'],
                        'away_win' => $team['away']['win'],
                        'away_draw' => $team['away']['draw'],
                        'away_lose' => $team['away']['lose'],
                        'away_goals_for' => $team['away']['goals']['for'],
                        'away_goals_against' => $team['away']['goals']['against']
                    ];
                    
                    $exists = $this->db->exists('standings', 'league_id = :league_id AND season = :season AND team_id = :team_id',
                        ['league_id' => $leagueId, 'season' => $season, 'team_id' => $team['team']['id']]);
                    
                    if ($exists) {
                        $this->db->update('standings', $data, 'league_id = :league_id AND season = :season AND team_id = :team_id',
                            ['league_id' => $leagueId, 'season' => $season, 'team_id' => $team['team']['id']]);
                    } else {
                        $this->db->insert('standings', $data);
                    }
                }
            }
        }
    }
    
    private function saveTopScorers($leagueId, $season, $scorers) {
        foreach ($scorers as $scorer) {
            $player = $scorer['player'];
            $statistics = $scorer['statistics'][0] ?? [];
            
            $data = [
                'league_id' => $leagueId,
                'season' => $season,
                'player_id' => $player['id'],
                'player_name' => $player['name'],
                'player_photo' => $player['photo'],
                'player_age' => $player['age'],
                'player_nationality' => $player['nationality'],
                'team_id' => $statistics['team']['id'] ?? null,
                'team_name' => $statistics['team']['name'] ?? null,
                'team_logo' => $statistics['team']['logo'] ?? null,
                'games_appearances' => $statistics['games']['appearences'] ?? 0,
                'games_minutes' => $statistics['games']['minutes'] ?? 0,
                'games_position' => $statistics['games']['position'] ?? null,
                'games_rating' => $statistics['games']['rating'] ?? null,
                'goals_total' => $statistics['goals']['total'] ?? 0,
                'goals_assists' => $statistics['goals']['assists'] ?? 0,
                'goals_saves' => $statistics['goals']['saves'] ?? null,
                'shots_total' => $statistics['shots']['total'] ?? 0,
                'shots_on' => $statistics['shots']['on'] ?? 0,
                'passes_total' => $statistics['passes']['total'] ?? 0,
                'passes_accuracy' => $statistics['passes']['accuracy'] ?? 0,
                'penalties_scored' => $statistics['penalty']['scored'] ?? 0,
                'penalties_missed' => $statistics['penalty']['missed'] ?? 0
            ];
            
            $exists = $this->db->exists('scorers', 'league_id = :league_id AND season = :season AND player_id = :player_id',
                ['league_id' => $leagueId, 'season' => $season, 'player_id' => $player['id']]);
            
            if ($exists) {
                $this->db->update('scorers', $data, 'league_id = :league_id AND season = :season AND player_id = :player_id',
                    ['league_id' => $leagueId, 'season' => $season, 'player_id' => $player['id']]);
            } else {
                $this->db->insert('scorers', $data);
            }
        }
    }
    
    private function saveTeams($teams) {
        foreach ($teams as $item) {
            $team = $item['team'];
            $venue = $item['venue'];
            
            $data = [
                'api_id' => $team['id'],
                'name' => $team['name'],
                'code' => $team['code'] ?? null,
                'country' => $team['country'] ?? null,
                'founded' => $team['founded'] ?? null,
                'national' => $team['national'] ?? 0,
                'logo' => $team['logo'] ?? null,
                'venue_id' => $venue['id'] ?? null,
                'venue_name' => $venue['name'] ?? null,
                'venue_address' => $venue['address'] ?? null,
                'venue_city' => $venue['city'] ?? null,
                'venue_capacity' => $venue['capacity'] ?? null,
                'venue_surface' => $venue['surface'] ?? null,
                'venue_image' => $venue['image'] ?? null
            ];
            
            $exists = $this->db->exists('teams', 'api_id = :api_id', ['api_id' => $team['id']]);
            
            if ($exists) {
                unset($data['api_id']);
                $this->db->update('teams', $data, 'api_id = :api_id', ['api_id' => $team['id']]);
            } else {
                $this->db->insert('teams', $data);
            }
        }
    }
    
    private function saveLeagues($leagues) {
        foreach ($leagues as $item) {
            $league = $item['league'];
            $country = $item['country'];
            $seasons = $item['seasons'];
            
            foreach ($seasons as $season) {
                $data = [
                    'api_id' => $league['id'],
                    'name' => $league['name'],
                    'type' => $league['type'] ?? null,
                    'logo' => $league['logo'] ?? null,
                    'country' => $country['name'] ?? null,
                    'country_code' => $country['code'] ?? null,
                    'country_flag' => $country['flag'] ?? null,
                    'season' => $season['year'],
                    'season_start' => $season['start'],
                    'season_end' => $season['end'],
                    'is_current' => $season['current'] ? 1 : 0
                ];
                
                $exists = $this->db->exists('leagues', 'api_id = :api_id AND season = :season',
                    ['api_id' => $league['id'], 'season' => $season['year']]);
                
                if (!$exists) {
                    $id = $this->db->lastInsertId();
                    if (!$id) {
                        $id = $this->db->count('leagues') + 1;
                    }
                    $data['id'] = $id;
                    $this->db->insert('leagues', $data);
                }
            }
        }
    }
    
    private function updateSystemUpdate($type, $count) {
        $this->db->update('system_updates', [
            'last_update' => date('Y-m-d H:i:s'),
            'status' => 'success',
            'records_count' => $count,
            'error_message' => null
        ], 'update_type = :type', ['type' => $type]);
    }
}