<?php
// تسجيل الخروج
// admin/logout.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

if (isLoggedIn()) {
    $db = Database::getInstance();
    
    // تسجيل الخروج في السجل
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'],
        'action_type' => 'logout',
        'action_description' => 'تسجيل خروج',
        'ip_address' => getClientIP(),
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'status' => 'success'
    ]);
}

// مسح الجلسة
session_unset();
session_destroy();

redirect(ADMIN_PATH . '/login.php');
?>