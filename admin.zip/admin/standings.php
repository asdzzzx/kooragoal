<?php
// الترتيب
// admin/standings.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$league_id = $_GET['league'] ?? 39;
$season = $_GET['season'] ?? date('Y');

$standings = $db->query(
    "SELECT * FROM standings 
     WHERE league_id = :league_id AND season = :season 
     ORDER BY rank ASC",
    ['league_id' => $league_id, 'season' => $season]
);

$leagues = $db->query(
    "SELECT DISTINCT league_id, league_name, league_logo 
     FROM fixtures 
     ORDER BY league_name"
);

$pageTitle = 'الترتيب';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-bar-chart"></i> ترتيب الدوري
                </h1>
                <button class="btn btn-primary" id="updateStandingsBtn">
                    <i class="bi bi-arrow-clockwise"></i> تحديث الترتيب
                </button>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-5">
                            <label class="form-label">الدوري</label>
                            <select class="form-select" name="league">
                                <?php foreach ($leagues as $lg): ?>
                                <option value="<?php echo $lg['league_id']; ?>"
                                        <?php echo $league_id == $lg['league_id'] ? 'selected' : ''; ?>>
                                    <?php echo $lg['league_name']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">الموسم</label>
                            <select class="form-select" name="season">
                                <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                <option value="<?php echo $y; ?>" <?php echo $season == $y ? 'selected' : ''; ?>>
                                    <?php echo $y; ?>
                                </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> عرض
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <?php if (empty($standings)): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i> لا توجد بيانات ترتيب لهذا الدوري
                </div>
            <?php else: ?>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>الفريق</th>
                                    <th>لعب</th>
                                    <th>فوز</th>
                                    <th>تعادل</th>
                                    <th>خسارة</th>
                                    <th>له</th>
                                    <th>عليه</th>
                                    <th>الفرق</th>
                                    <th>النقاط</th>
                                    <th>الشكل</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($standings as $team): ?>
                                <tr>
                                    <td>
                                        <strong class="text-primary"><?php echo $team['rank']; ?></strong>
                                    </td>
                                    <td>
                                        <img src="<?php echo $team['team_logo']; ?>" width="25" class="me-2" alt="">
                                        <strong><?php echo $team['team_name']; ?></strong>
                                    </td>
                                    <td><?php echo $team['played']; ?></td>
                                    <td class="text-success"><?php echo $team['win']; ?></td>
                                    <td class="text-warning"><?php echo $team['draw']; ?></td>
                                    <td class="text-danger"><?php echo $team['lose']; ?></td>
                                    <td><?php echo $team['goals_for']; ?></td>
                                    <td><?php echo $team['goals_against']; ?></td>
                                    <td>
                                        <span class="badge <?php echo $team['goals_diff'] >= 0 ? 'bg-success' : 'bg-danger'; ?>">
                                            <?php echo $team['goals_diff'] > 0 ? '+' : ''; ?><?php echo $team['goals_diff']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong class="text-primary fs-5"><?php echo $team['points']; ?></strong>
                                    </td>
                                    <td>
                                        <?php if ($team['form']): ?>
                                            <?php foreach (str_split($team['form']) as $f): ?>
                                                <span class="badge 
                                                    <?php echo $f === 'W' ? 'bg-success' : ($f === 'D' ? 'bg-warning' : 'bg-danger'); ?>">
                                                    <?php echo $f; ?>
                                                </span>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<script>
document.getElementById('updateStandingsBtn').addEventListener('click', function() {
    const btn = this;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري التحديث...';
    
    const league = <?php echo $league_id; ?>;
    const season = <?php echo $season; ?>;
    
    fetch('ajax/update_standings.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `league=${league}&season=${season}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess('تم تحديث الترتيب بنجاح');
            setTimeout(() => location.reload(), 1000);
        } else {
            showError(data.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> تحديث الترتيب';
        }
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>