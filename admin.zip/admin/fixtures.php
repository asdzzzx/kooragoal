<?php
// صفحة المباريات
// admin/fixtures.php

// تفعيل عرض الأخطاء للتشخيص (احذفها بعد حل المشكلة)
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

// الفلترة
$date = isset($_GET['date']) ? clean($_GET['date']) : date('Y-m-d');
$league_id = isset($_GET['league']) ? clean($_GET['league']) : '';
$status = isset($_GET['status']) ? clean($_GET['status']) : '';

// بناء الاستعلام
$where = "DATE(date) = :date";
$params = ['date' => $date];

if (!empty($league_id) && is_numeric($league_id)) {
    $where .= " AND league_id = :league_id";
    $params['league_id'] = $league_id;
}

if (!empty($status)) {
    $where .= " AND status_short = :status";
    $params['status'] = $status;
}

// جلب المباريات
try {
    $fixtures = $db->query(
        "SELECT * FROM fixtures WHERE {$where} ORDER BY date ASC",
        $params
    );
    
    if ($fixtures === false) {
        $fixtures = [];
    }
} catch (Exception $e) {
    $fixtures = [];
    error_log("Error fetching fixtures: " . $e->getMessage());
}

// جلب الدوريات للفلتر
try {
    $leagues = $db->query(
        "SELECT DISTINCT league_id, league_name, league_logo 
         FROM fixtures 
         WHERE league_id IS NOT NULL
         ORDER BY league_name"
    );
    
    if ($leagues === false) {
        $leagues = [];
    }
} catch (Exception $e) {
    $leagues = [];
    error_log("Error fetching leagues: " . $e->getMessage());
}

$pageTitle = 'إدارة المباريات';
require_once __DIR__ . '/includes/header.php';
?>

<?php require_once __DIR__ . '/includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">
            <i class="bi bi-calendar-event"></i> المباريات
        </h1>
        <div class="btn-toolbar">
            <button type="button" class="btn btn-primary" id="fetchTodayBtn">
                <i class="bi bi-cloud-download"></i> جلب مباريات اليوم
            </button>
        </div>
    </div>
    
    <!-- الفلاتر -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">التاريخ</label>
                    <input type="date" class="form-control" name="date" 
                           value="<?php echo htmlspecialchars($date); ?>">
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">الدوري</label>
                    <select class="form-select" name="league">
                        <option value="">جميع الدوريات</option>
                        <?php foreach ($leagues as $league): ?>
                        <option value="<?php echo htmlspecialchars($league['league_id']); ?>"
                                <?php echo $league_id == $league['league_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($league['league_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">الحالة</label>
                    <select class="form-select" name="status">
                        <option value="">جميع الحالات</option>
                        <option value="NS" <?php echo $status === 'NS' ? 'selected' : ''; ?>>لم تبدأ</option>
                        <option value="1H" <?php echo $status === '1H' ? 'selected' : ''; ?>>الشوط الأول</option>
                        <option value="HT" <?php echo $status === 'HT' ? 'selected' : ''; ?>>استراحة</option>
                        <option value="2H" <?php echo $status === '2H' ? 'selected' : ''; ?>>الشوط الثاني</option>
                        <option value="FT" <?php echo $status === 'FT' ? 'selected' : ''; ?>>انتهت</option>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i> بحث
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- جدول المباريات -->
    <div class="card">
        <div class="card-header">
            <h6 class="m-0">
                <i class="bi bi-list"></i> 
                عدد المباريات: <?php echo count($fixtures); ?>
            </h6>
        </div>
        <div class="card-body">
            <?php if (empty($fixtures)): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i>
                    لا توجد مباريات في هذا التاريخ
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>المعرف</th>
                                <th>التاريخ</th>
                                <th>الدوري</th>
                                <th>المباراة</th>
                                <th>النتيجة</th>
                                <th>الحالة</th>
                                <th>إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($fixtures as $fixture): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($fixture['api_id']); ?></td>
                                <td>
                                    <?php 
                                    if (!empty($fixture['date'])) {
                                        echo formatDate($fixture['date'], 'Y-m-d H:i');
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php if (!empty($fixture['league_logo'])): ?>
                                        <img src="<?php echo htmlspecialchars($fixture['league_logo']); ?>" 
                                             width="20" class="me-1" alt="" onerror="this.style.display='none'">
                                    <?php endif; ?>
                                    <?php echo htmlspecialchars($fixture['league_name'] ?? ''); ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php if (!empty($fixture['home_team_logo'])): ?>
                                            <img src="<?php echo htmlspecialchars($fixture['home_team_logo']); ?>" 
                                                 width="25" class="me-2" alt="" onerror="this.style.display='none'">
                                        <?php endif; ?>
                                        <strong><?php echo htmlspecialchars($fixture['home_team_name'] ?? ''); ?></strong>
                                        <span class="mx-2">vs</span>
                                        <?php if (!empty($fixture['away_team_logo'])): ?>
                                            <img src="<?php echo htmlspecialchars($fixture['away_team_logo']); ?>" 
                                                 width="25" class="me-2" alt="" onerror="this.style.display='none'">
                                        <?php endif; ?>
                                        <strong><?php echo htmlspecialchars($fixture['away_team_name'] ?? ''); ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($fixture['goals_home'] !== null && $fixture['goals_away'] !== null): ?>
                                        <span class="badge bg-primary fs-6">
                                            <?php echo htmlspecialchars($fixture['goals_home']); ?> - <?php echo htmlspecialchars($fixture['goals_away']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $statusShort = $fixture['status_short'] ?? 'NS';
                                    $statusClass = 'bg-secondary';
                                    
                                    if (in_array($statusShort, ['1H', '2H', 'ET'])) {
                                        $statusClass = 'bg-danger blink';
                                    } elseif ($statusShort === 'HT') {
                                        $statusClass = 'bg-warning';
                                    } elseif (in_array($statusShort, ['FT', 'AET', 'PEN'])) {
                                        $statusClass = 'bg-success';
                                    } elseif ($statusShort === 'NS') {
                                        $statusClass = 'bg-secondary';
                                    } else {
                                        $statusClass = 'bg-info';
                                    }
                                    ?>
                                    <span class="badge <?php echo $statusClass; ?>">
                                        <?php echo htmlspecialchars(getMatchStatusAr($statusShort)); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="match_details.php?id=<?php echo htmlspecialchars($fixture['api_id']); ?>" 
                                           class="btn btn-info" title="عرض التفاصيل">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <button class="btn btn-primary update-match" 
                                                data-id="<?php echo htmlspecialchars($fixture['api_id']); ?>"
                                                title="تحديث">
                                            <i class="bi bi-arrow-clockwise"></i>
                                        </button>
                                        <button class="btn btn-danger delete-match" 
                                                data-id="<?php echo htmlspecialchars($fixture['id']); ?>"
                                                title="حذف">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<script>
// جلب مباريات اليوم
document.getElementById('fetchTodayBtn')?.addEventListener('click', function() {
    const btn = this;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري الجلب...';
    
    fetch('ajax/manual_update.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'type=daily_fixtures'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess(data.message);
            setTimeout(() => location.reload(), 1500);
        } else {
            showError(data.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-cloud-download"></i> جلب مباريات اليوم';
        }
    })
    .catch(error => {
        showError('حدث خطأ في الاتصال');
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-cloud-download"></i> جلب مباريات اليوم';
    });
});

// تحديث مباراة معينة
document.querySelectorAll('.update-match').forEach(btn => {
    btn.addEventListener('click', function() {
        const matchId = this.dataset.id;
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        
        fetch('ajax/update_match.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'match_id=' + matchId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccess('تم تحديث المباراة');
                setTimeout(() => location.reload(), 1000);
            } else {
                showError(data.message);
                this.disabled = false;
                this.innerHTML = '<i class="bi bi-arrow-clockwise"></i>';
            }
        })
        .catch(error => {
            showError('حدث خطأ في التحديث');
            this.disabled = false;
            this.innerHTML = '<i class="bi bi-arrow-clockwise"></i>';
        });
    });
});

// حذف مباراة
document.querySelectorAll('.delete-match').forEach(btn => {
    btn.addEventListener('click', function() {
        if (!confirm('هل تريد حذف هذه المباراة؟')) return;
        
        const id = this.dataset.id;
        
        fetch('ajax/delete_match.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccess('تم الحذف بنجاح');
                setTimeout(() => location.reload(), 1000);
            } else {
                showError(data.message);
            }
        })
        .catch(error => {
            showError('حدث خطأ في الحذف');
        });
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>