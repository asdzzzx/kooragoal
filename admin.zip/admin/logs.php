<?php
// السجلات
// admin/logs.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$type = $_GET['type'] ?? '';
$date = $_GET['date'] ?? '';

$where = "1=1";
$params = [];

if (!empty($type)) {
    $where .= " AND action_type = :type";
    $params['type'] = $type;
}

if (!empty($date)) {
    $where .= " AND DATE(created_at) = :date";
    $params['date'] = $date;
}

$logs = $db->query(
    "SELECT l.*, a.username 
     FROM logs l 
     LEFT JOIN admins a ON l.admin_id = a.id 
     WHERE {$where} 
     ORDER BY l.created_at DESC 
     LIMIT 200",
    $params
);

$types = $db->query(
    "SELECT DISTINCT action_type FROM logs ORDER BY action_type"
);

$pageTitle = 'السجلات';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-list-ul"></i> سجل الأنشطة
                </h1>
                <button class="btn btn-danger" onclick="if(confirm('حذف جميع السجلات؟')) clearLogs()">
                    <i class="bi bi-trash"></i> حذف الكل
                </button>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">نوع النشاط</label>
                            <select class="form-select" name="type">
                                <option value="">الكل</option>
                                <?php foreach ($types as $t): ?>
                                <option value="<?php echo $t['action_type']; ?>"
                                        <?php echo $type === $t['action_type'] ? 'selected' : ''; ?>>
                                    <?php echo $t['action_type']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">التاريخ</label>
                            <input type="date" class="form-control" name="date" value="<?php echo $date; ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> بحث
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h6 class="m-0">عدد السجلات: <?php echo count($logs); ?></h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>المستخدم</th>
                                    <th>النوع</th>
                                    <th>الوصف</th>
                                    <th>IP</th>
                                    <th>الحالة</th>
                                    <th>التاريخ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?php echo $log['id']; ?></td>
                                    <td><?php echo $log['username'] ?? 'نظام'; ?></td>
                                    <td>
                                        <span class="badge bg-secondary">
                                            <?php echo $log['action_type']; ?>
                                        </span>
                                    </td>
                                    <td><small><?php echo $log['action_description']; ?></small></td>
                                    <td><small class="text-muted"><?php echo $log['ip_address']; ?></small></td>
                                    <td>
                                        <?php if ($log['status'] === 'success'): ?>
                                            <span class="badge bg-success">نجح</span>
                                        <?php elseif ($log['status'] === 'failed'): ?>
                                            <span class="badge bg-danger">فشل</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">تحذير</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small><?php echo formatDate($log['created_at'], 'Y-m-d H:i:s'); ?></small>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function clearLogs() {
    fetch('ajax/clear_logs.php', {method: 'POST'})
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccess('تم حذف السجلات');
                setTimeout(() => location.reload(), 1000);
            } else {
                showError(data.message);
            }
        });
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>