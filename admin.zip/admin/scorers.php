<?php
// الهدافين
// admin/scorers.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$league_id = $_GET['league'] ?? 39;
$season = $_GET['season'] ?? date('Y');

$scorers = $db->query(
    "SELECT * FROM scorers 
     WHERE league_id = :league_id AND season = :season 
     ORDER BY goals_total DESC 
     LIMIT 50",
    ['league_id' => $league_id, 'season' => $season]
);

$leagues = $db->query(
    "SELECT DISTINCT league_id, league_name FROM fixtures ORDER BY league_name"
);

$pageTitle = 'الهدافين';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-award"></i> قائمة الهدافين
                </h1>
                <button class="btn btn-primary" id="updateScorersBtn">
                    <i class="bi bi-arrow-clockwise"></i> تحديث الهدافين
                </button>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-5">
                            <label class="form-label">الدوري</label>
                            <select class="form-select" name="league">
                                <?php foreach ($leagues as $lg): ?>
                                <option value="<?php echo $lg['league_id']; ?>"
                                        <?php echo $league_id == $lg['league_id'] ? 'selected' : ''; ?>>
                                    <?php echo $lg['league_name']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">الموسم</label>
                            <select class="form-select" name="season">
                                <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                <option value="<?php echo $y; ?>" <?php echo $season == $y ? 'selected' : ''; ?>>
                                    <?php echo $y; ?>
                                </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> عرض
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <?php if (empty($scorers)): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i> لا توجد بيانات هدافين لهذا الدوري
                </div>
            <?php else: ?>
            <div class="row">
                <?php foreach ($scorers as $index => $scorer): ?>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="text-center me-3">
                                    <h2 class="text-primary mb-0"><?php echo $index + 1; ?></h2>
                                </div>
                                
                                <img src="<?php echo $scorer['player_photo']; ?>" 
                                     width="60" height="60" 
                                     class="rounded-circle me-3" 
                                     style="object-fit: cover;" alt="">
                                
                                <div class="flex-grow-1">
                                    <h5 class="mb-1"><?php echo $scorer['player_name']; ?></h5>
                                    <div class="d-flex align-items-center text-muted">
                                        <img src="<?php echo $scorer['team_logo']; ?>" width="20" class="me-1" alt="">
                                        <small><?php echo $scorer['team_name']; ?></small>
                                    </div>
                                </div>
                                
                                <div class="text-center">
                                    <h3 class="text-success mb-0">
                                        <i class="bi bi-trophy-fill"></i>
                                        <?php echo $scorer['goals_total']; ?>
                                    </h3>
                                    <small class="text-muted">هدف</small>
                                </div>
                            </div>
                            
                            <hr>
                            
                            <div class="row text-center small">
                                <div class="col-4">
                                    <div class="text-muted">مباريات</div>
                                    <strong><?php echo $scorer['games_appearances']; ?></strong>
                                </div>
                                <div class="col-4">
                                    <div class="text-muted">تمريرات حاسمة</div>
                                    <strong><?php echo $scorer['goals_assists']; ?></strong>
                                </div>
                                <div class="col-4">
                                    <div class="text-muted">ركلات جزاء</div>
                                    <strong><?php echo $scorer['penalties_scored']; ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<script>
document.getElementById('updateScorersBtn').addEventListener('click', function() {
    const btn = this;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري التحديث...';
    
    const league = <?php echo $league_id; ?>;
    const season = <?php echo $season; ?>;
    
    fetch('ajax/update_scorers.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `league=${league}&season=${season}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess('تم تحديث الهدافين بنجاح');
            setTimeout(() => location.reload(), 1000);
        } else {
            showError(data.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> تحديث الهدافين';
        }
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>