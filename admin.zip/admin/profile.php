<?php
// الملف الشخصي
// admin/profile.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $admin = $db->queryOne("SELECT * FROM admins WHERE id = :id", ['id' => $_SESSION['admin_id']]);
    
    if (!password_verify($current_password, $admin['password'])) {
        $error = 'كلمة المرور الحالية غير صحيحة';
    } elseif (strlen($new_password) < 6) {
        $error = 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل';
    } elseif ($new_password !== $confirm_password) {
        $error = 'كلمتا المرور غير متطابقتين';
    } else {
        $db->update('admins', 
            ['password' => password_hash($new_password, PASSWORD_DEFAULT)],
            'id = :id',
            ['id' => $_SESSION['admin_id']]
        );
        $message = 'تم تغيير كلمة المرور بنجاح';
    }
}

$admin = $db->queryOne("SELECT * FROM admins WHERE id = :id", ['id' => $_SESSION['admin_id']]);

$pageTitle = 'الملف الشخصي';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-person-circle"></i> الملف الشخصي
                </h1>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">المعلومات الأساسية</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">اسم المستخدم</label>
                                <input type="text" class="form-control" value="<?php echo $admin['username']; ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">الاسم الكامل</label>
                                <input type="text" class="form-control" value="<?php echo $admin['full_name']; ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">البريد الإلكتروني</label>
                                <input type="email" class="form-control" value="<?php echo $admin['email']; ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">الصلاحية</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo $admin['role'] === 'super_admin' ? 'مدير عام' : 
                                                      ($admin['role'] === 'admin' ? 'مسؤول' : 'محرر'); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">آخر تسجيل دخول</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo formatDate($admin['last_login']); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">تغيير كلمة المرور</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">كلمة المرور الحالية</label>
                                    <input type="password" class="form-control" name="current_password" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">كلمة المرور الجديدة</label>
                                    <input type="password" class="form-control" name="new_password" 
                                           minlength="6" required>
                                    <small class="text-muted">6 أحرف على الأقل</small>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">تأكيد كلمة المرور</label>
                                    <input type="password" class="form-control" name="confirm_password" required>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> حفظ التغييرات
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>