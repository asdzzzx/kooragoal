<?php
// ============================================
// public/stats.php - إحصائيات المباراة
// ============================================
?>
<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
$db = Database::getInstance();
$match_id = $_GET['match_id'] ?? 0;
$stats = $db->query("SELECT * FROM statistics WHERE fixture_id = :id", ['id' => $match_id]);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إحصائيات المباراة - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1>الإحصائيات</h1>
        <?php if (count($stats) >= 2): 
            $home = $stats[0]; $away = $stats[1]; ?>
        <table class="table">
            <tbody>
                <tr>
                    <td><?php echo $home['ball_possession']; ?></td>
                    <td class="text-center">الاستحواذ</td>
                    <td><?php echo $away['ball_possession']; ?></td>
                </tr>
                <tr>
                    <td><?php echo $home['total_shots']; ?></td>
                    <td class="text-center">التسديدات</td>
                    <td><?php echo $away['total_shots']; ?></td>
                </tr>
                <tr>
                    <td><?php echo $home['shots_on_goal']; ?></td>
                    <td class="text-center">على المرمى</td>
                    <td><?php echo $away['shots_on_goal']; ?></td>
                </tr>
                <tr>
                    <td><?php echo $home['corner_kicks']; ?></td>
                    <td class="text-center">الركنيات</td>
                    <td><?php echo $away['corner_kicks']; ?></td>
                </tr>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</body>
</html>