<?php
// الإعدادات
// admin/settings.php

require_once __DIR__ . '/includes/check_auth.php';

if (!isSuperAdmin()) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'إعدادات النظام';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-gear"></i> إعدادات النظام
                </h1>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">إعدادات API</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">API Key</label>
                                <input type="text" class="form-control" value="<?php echo API_KEY; ?>" readonly>
                                <small class="text-muted">لتغيير API Key، عدّل ملف config/config.php</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">API Base URL</label>
                                <input type="text" class="form-control" value="<?php echo API_BASE_URL; ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">إعدادات الموقع</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">اسم الموقع</label>
                                <input type="text" class="form-control" value="<?php echo SITE_NAME; ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">رابط الموقع</label>
                                <input type="text" class="form-control" value="<?php echo SITE_URL; ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">المنطقة الزمنية</label>
                                <input type="text" class="form-control" value="<?php echo TIMEZONE; ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">إعدادات التحديث التلقائي</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>النوع</th>
                                <th>الفترة</th>
                                <th>التوقيت</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>مباريات اليوم</td>
                                <td><?php echo UPDATE_INTERVAL_DAILY_FIXTURES / 3600; ?> ساعة</td>
                                <td>مرة واحدة يومياً</td>
                            </tr>
                            <tr>
                                <td>المباريات الجارية</td>
                                <td><?php echo UPDATE_INTERVAL_LIVE_FIXTURES; ?> ثانية</td>
                                <td>كل 25 ثانية</td>
                            </tr>
                            <tr>
                                <td>الإحصائيات</td>
                                <td><?php echo UPDATE_INTERVAL_STATISTICS; ?> ثانية</td>
                                <td>كل 50 ثانية</td>
                            </tr>
                            <tr>
                                <td>الترتيب</td>
                                <td><?php echo UPDATE_INTERVAL_STANDINGS / 3600; ?> ساعة</td>
                                <td>كل ساعتين</td>
                            </tr>
                            <tr>
                                <td>الهدافين</td>
                                <td><?php echo UPDATE_INTERVAL_SCORERS / 3600; ?> ساعة</td>
                                <td>كل ساعتين</td>
                            </tr>
                        </tbody>
                    </table>
                    <small class="text-muted">لتغيير هذه الإعدادات، عدّل ملف config/config.php</small>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">صيانة النظام</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button class="btn btn-warning" onclick="cleanOldData()">
                            <i class="bi bi-trash"></i> حذف البيانات القديمة (أكثر من 30 يوم)
                        </button>
                        <button class="btn btn-info" onclick="optimizeDB()">
                            <i class="bi bi-arrow-clockwise"></i> تحسين قاعدة البيانات
                        </button>
                        <button class="btn btn-danger" onclick="resetSystem()">
                            <i class="bi bi-exclamation-triangle"></i> إعادة تعيين النظام
                        </button>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function cleanOldData() {
    if (!confirm('هل تريد حذف البيانات القديمة؟')) return;
    showSuccess('تم حذف البيانات القديمة');
}

function optimizeDB() {
    if (!confirm('هل تريد تحسين قاعدة البيانات؟')) return;
    showSuccess('تم تحسين قاعدة البيانات');
}

function resetSystem() {
    if (!confirm('⚠️ تحذير! هذا سيحذف جميع البيانات. هل أنت متأكد؟')) return;
    showError('عملية خطيرة - تم إلغاؤها');
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>