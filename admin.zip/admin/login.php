<?php
// صفحة تسجيل الدخول للوحة التحكم
// admin/login.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

// إذا كان مسجل الدخول، توجيه للوحة التحكم
if (isLoggedIn()) {
    redirect(ADMIN_PATH . '/index.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'يرجى إدخال اسم المستخدم وكلمة المرور';
    } else {
        $db = Database::getInstance();
        
        // التحقق من المستخدم
        $admin = $db->queryOne(
            "SELECT * FROM admins WHERE username = :username AND status = 'active'",
            ['username' => $username]
        );
        
        if ($admin) {
            // التحقق من القفل المؤقت
            if ($admin['locked_until'] && strtotime($admin['locked_until']) > time()) {
                $remaining = ceil((strtotime($admin['locked_until']) - time()) / 60);
                $error = "الحساب مقفل مؤقتاً. يرجى المحاولة بعد {$remaining} دقيقة";
            } else {
                // التحقق من كلمة المرور
                if (password_verify($password, $admin['password'])) {
                    // تسجيل دخول ناجح
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_username'] = $admin['username'];
                    $_SESSION['admin_role'] = $admin['role'];
                    $_SESSION['admin_name'] = $admin['full_name'];
                    $_SESSION['last_activity'] = time();
                    
                    // تحديث آخر دخول وإعادة تعيين المحاولات
                    $db->update(
                        'admins',
                        [
                            'last_login' => date('Y-m-d H:i:s'),
                            'login_attempts' => 0,
                            'locked_until' => null
                        ],
                        'id = :id',
                        ['id' => $admin['id']]
                    );
                    
                    // تسجيل في السجل
                    $db->insert('logs', [
                        'admin_id' => $admin['id'],
                        'action_type' => 'login',
                        'action_description' => 'تسجيل دخول ناجح',
                        'ip_address' => getClientIP(),
                        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                        'status' => 'success'
                    ]);
                    
                    redirect(ADMIN_PATH . '/index.php');
                } else {
                    // كلمة مرور خاطئة
                    $attempts = $admin['login_attempts'] + 1;
                    
                    $updateData = ['login_attempts' => $attempts];
                    
                    // قفل الحساب بعد 5 محاولات فاشلة
                    if ($attempts >= MAX_LOGIN_ATTEMPTS) {
                        $updateData['locked_until'] = date('Y-m-d H:i:s', time() + LOCK_TIME);
                        $error = 'تم قفل الحساب مؤقتاً لمدة 15 دقيقة بسبب المحاولات الفاشلة المتكررة';
                    } else {
                        $remaining = MAX_LOGIN_ATTEMPTS - $attempts;
                        $error = "كلمة المرور غير صحيحة. المحاولات المتبقية: {$remaining}";
                    }
                    
                    $db->update('admins', $updateData, 'id = :id', ['id' => $admin['id']]);
                    
                    // تسجيل في السجل
                    $db->insert('logs', [
                        'admin_id' => $admin['id'],
                        'action_type' => 'login_failed',
                        'action_description' => 'محاولة تسجيل دخول فاشلة',
                        'ip_address' => getClientIP(),
                        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                        'status' => 'failed'
                    ]);
                }
            }
        } else {
            $error = 'اسم المستخدم غير موجود أو الحساب غير نشط';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - لوحة التحكم</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Cairo', sans-serif;
        }
        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 40px;
            max-width: 450px;
            width: 100%;
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h2 {
            color: #667eea;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .login-header p {
            color: #6c757d;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            border: 2px solid #e9ecef;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-weight: bold;
            color: white;
            width: 100%;
            transition: transform 0.2s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102,126,234,0.4);
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-header">
            <i class="bi bi-shield-lock" style="font-size: 50px; color: #667eea;"></i>
            <h2>لوحة التحكم</h2>
            <p>قم بتسجيل الدخول للوصول إلى النظام</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i>
                <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-3">
                <label for="username" class="form-label">
                    <i class="bi bi-person-fill"></i> اسم المستخدم
                </label>
                <input type="text" class="form-control" id="username" name="username" 
                       placeholder="أدخل اسم المستخدم" required autofocus>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">
                    <i class="bi bi-lock-fill"></i> كلمة المرور
                </label>
                <input type="password" class="form-control" id="password" name="password" 
                       placeholder="أدخل كلمة المرور" required>
            </div>
            
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="remember">
                <label class="form-check-label" for="remember">
                    تذكرني
                </label>
            </div>
            
            <button type="submit" class="btn btn-login">
                <i class="bi bi-box-arrow-in-left"></i> تسجيل الدخول
            </button>
        </form>
        
        <div class="text-center mt-4">
            <small class="text-muted">
                © 2025 <?php echo SITE_NAME; ?> - جميع الحقوق محفوظة
            </small>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>