<?php
// الصفحة الرئيسية للوحة التحكم
// admin/index.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Scheduler.php';
require_once __DIR__ . '/../classes/ApiUsageTracker.php';

$db = Database::getInstance();
$scheduler = new Scheduler();
$usageTracker = new ApiUsageTracker();

// إحصائيات عامة
$stats = [
    'leagues' => $db->count('leagues'),
    'teams' => $db->count('teams'),
    'fixtures_today' => $db->count('fixtures', 'DATE(date) = CURDATE()'),
    'fixtures_live' => $db->count('fixtures', 'is_live = 1'),
    'total_fixtures' => $db->count('fixtures')
];

// استهلاك API
$todayUsage = $usageTracker->getTodayUsage();
$monthUsage = $usageTracker->getMonthUsage();
$dailyLimit = 100; // الحد اليومي
$monthlyLimit = 3000; // الحد الشهري
$usagePercentage = $usageTracker->getUsagePercentage($dailyLimit);

// آخر التحديثات
$updates = $scheduler->getUpdateStatus();

// آخر السجلات
$logs = $db->query(
    "SELECT * FROM logs ORDER BY created_at DESC LIMIT 10"
);

$pageTitle = 'لوحة التحكم الرئيسية';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <!-- الشريط الجانبي -->
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <!-- المحتوى الرئيسي -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-speedometer2"></i> لوحة التحكم
                </h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-success me-2" id="initialFetchBtn">
                        <i class="bi bi-cloud-download"></i> سحب جميع البيانات (أول مرة)
                    </button>
                    <button type="button" class="btn btn-primary" id="refreshBtn">
                        <i class="bi bi-arrow-clockwise"></i> تحديث التلقائي
                    </button>
                </div>
            </div>
            
            <!-- رسالة التقدم -->
            <div id="progressAlert" class="alert alert-info d-none" role="alert">
                <div class="d-flex align-items-center">
                    <div class="spinner-border spinner-border-sm me-2" role="status">
                        <span class="visually-hidden">جاري التحميل...</span>
                    </div>
                    <div>
                        <strong>جاري السحب...</strong>
                        <div id="progressMessage">يرجى الانتظار...</div>
                        <div class="progress mt-2" style="height: 20px;">
                            <div id="progressBar" class="progress-bar progress-bar-striped progress-bar-animated" 
                                 role="progressbar" style="width: 0%">0%</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- بطاقات الإحصائيات -->
            <div class="row mb-4">
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        الدوريات
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['leagues']); ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-trophy-fill fa-2x text-gray-300" style="font-size: 2rem; color: #4e73df;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        الفرق
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['teams']); ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-people-fill fa-2x text-gray-300" style="font-size: 2rem; color: #1cc88a;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-info shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                        مباريات اليوم
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['fixtures_today']); ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-calendar-event-fill fa-2x text-gray-300" style="font-size: 2rem; color: #36b9cc;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                        مباريات جارية
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['fixtures_live']); ?>
                                        <span class="badge bg-danger blink ms-2">LIVE</span>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-broadcast fa-2x text-gray-300" style="font-size: 2rem; color: #f6c23e;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- استهلاك API -->
            <div class="card shadow mb-4">
                <div class="card-header bg-gradient-primary text-white">
                    <h6 class="m-0 font-weight-bold">
                        <i class="bi bi-speedometer2"></i> استهلاك طلبات API
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- اليوم -->
                        <div class="col-md-6 mb-4">
                            <h6 class="text-primary mb-3">
                                <i class="bi bi-calendar-day"></i> استهلاك اليوم
                            </h6>
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <div class="text-center p-3 border rounded">
                                        <h3 class="mb-0 <?php echo $usagePercentage > 80 ? 'text-danger' : 'text-success'; ?>">
                                            <?php echo $todayUsage['total_requests']; ?>
                                        </h3>
                                        <small class="text-muted">من <?php echo $dailyLimit; ?> طلب</small>
                                    </div>
                                </div>
                                <div class="col-6 mb-3">
                                    <div class="text-center p-3 border rounded">
                                        <h3 class="mb-0 text-info">
                                            <?php echo number_format($usagePercentage, 1); ?>%
                                        </h3>
                                        <small class="text-muted">نسبة الاستخدام</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-center p-3 border rounded">
                                        <h4 class="mb-0 text-success">
                                            <?php echo $todayUsage['successful_requests']; ?>
                                        </h4>
                                        <small class="text-muted">ناجح</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-center p-3 border rounded">
                                        <h4 class="mb-0 text-danger">
                                            <?php echo $todayUsage['failed_requests']; ?>
                                        </h4>
                                        <small class="text-muted">فاشل</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- شريط التقدم -->
                            <div class="mt-3">
                                <div class="progress" style="height: 25px;">
                                    <div class="progress-bar <?php 
                                        echo $usagePercentage > 90 ? 'bg-danger' : 
                                            ($usagePercentage > 80 ? 'bg-warning' : 'bg-success'); 
                                    ?>" 
                                         role="progressbar" 
                                         style="width: <?php echo $usagePercentage; ?>%">
                                        <?php echo number_format($usagePercentage, 1); ?>%
                                    </div>
                                </div>
                                <small class="text-muted">
                                    متبقي: <?php echo $dailyLimit - $todayUsage['total_requests']; ?> طلب
                                </small>
                            </div>
                        </div>
                        
                        <!-- الشهر -->
                        <div class="col-md-6 mb-4">
                            <h6 class="text-success mb-3">
                                <i class="bi bi-calendar-month"></i> استهلاك الشهر
                            </h6>
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <div class="text-center p-3 border rounded">
                                        <h3 class="mb-0 text-primary">
                                            <?php echo number_format($monthUsage['total_requests']); ?>
                                        </h3>
                                        <small class="text-muted">إجمالي الطلبات</small>
                                    </div>
                                </div>
                                <div class="col-6 mb-3">
                                    <div class="text-center p-3 border rounded">
                                        <h3 class="mb-0 text-info">
                                            <?php echo number_format(($monthUsage['total_requests'] / $monthlyLimit) * 100, 1); ?>%
                                        </h3>
                                        <small class="text-muted">من <?php echo number_format($monthlyLimit); ?></small>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="text-center p-3 border rounded">
                                        <h5 class="mb-0 text-secondary">
                                            <?php echo ApiUsageTracker::formatBytes($monthUsage['total_data_size']); ?>
                                        </h5>
                                        <small class="text-muted">حجم البيانات المستلمة</small>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if (!empty($todayUsage['last_request_time'])): ?>
                            <div class="alert alert-info mt-3 mb-0">
                                <small>
                                    <i class="bi bi-clock"></i> آخر طلب: 
                                    <?php echo formatDate($todayUsage['last_request_time'], 'Y-m-d H:i:s'); ?>
                                </small>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- تحذير إذا اقترب من الحد -->
                    <?php if ($usagePercentage > 80): ?>
                    <div class="alert alert-warning mb-0">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                        <strong>تنبيه!</strong> 
                        لقد استهلكت <?php echo number_format($usagePercentage, 1); ?>% من الحد اليومي للطلبات.
                        <?php if ($usagePercentage > 90): ?>
                            <br>يرجى تقليل عدد الطلبات لتجنب تجاوز الحد المسموح.
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- جدول حالة التحديثات -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="bi bi-clock-history"></i> حالة التحديثات
                    </h6>
                    <button class="btn btn-sm btn-outline-primary" onclick="location.reload()">
                        <i class="bi bi-arrow-clockwise"></i> تحديث
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>نوع التحديث</th>
                                    <th>آخر تحديث</th>
                                    <th>عدد السجلات</th>
                                    <th>الحالة</th>
                                    <th>إجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($updates as $update): ?>
                                <tr>
                                    <td>
                                        <?php 
                                        $types = [
                                            'daily_fixtures' => 'مباريات اليوم',
                                            'live_fixtures' => 'المباريات الجارية',
                                            'fixtures_statistics' => 'إحصائيات المباريات',
                                            'fixtures_events' => 'أحداث المباريات',
                                            'fixtures_lineups' => 'التشكيلات',
                                            'leagues_standings' => 'الترتيب',
                                            'leagues_scorers' => 'الهدافين',
                                            'teams_data' => 'بيانات الفرق',
                                            'players_data' => 'بيانات اللاعبين'
                                        ];
                                        echo $types[$update['update_type']] ?? $update['update_type'];
                                        ?>
                                    </td>
                                    <td><?php echo formatDate($update['last_update']); ?></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <?php echo number_format($update['records_count']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($update['status'] === 'success'): ?>
                                            <span class="badge bg-success">
                                                <i class="bi bi-check-circle"></i> نجح
                                            </span>
                                        <?php elseif ($update['status'] === 'failed'): ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-x-circle"></i> فشل
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">
                                                <i class="bi bi-hourglass-split"></i> جاري
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary manual-update" 
                                                data-type="<?php echo $update['update_type']; ?>">
                                            <i class="bi bi-play-fill"></i> تشغيل
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- سجل الأنشطة الأخيرة -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="bi bi-list-ul"></i> آخر الأنشطة
                    </h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>النوع</th>
                                    <th>الوصف</th>
                                    <th>الحالة</th>
                                    <th>التاريخ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><span class="badge bg-secondary"><?php echo $log['action_type']; ?></span></td>
                                    <td><?php echo $log['action_description']; ?></td>
                                    <td>
                                        <?php if ($log['status'] === 'success'): ?>
                                            <span class="badge bg-success">نجح</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">فشل</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo formatDate($log['created_at']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
.blink {
    animation: blinker 1.5s linear infinite;
}
@keyframes blinker {
    50% { opacity: 0.5; }
}
.border-right-primary { border-right: 4px solid #4e73df !important; }
.border-right-success { border-right: 4px solid #1cc88a !important; }
.border-right-info { border-right: 4px solid #36b9cc !important; }
.border-right-warning { border-right: 4px solid #f6c23e !important; }
</style>

<script>
// زر السحب الشامل للبيانات
document.getElementById('initialFetchBtn').addEventListener('click', function() {
    if (!confirm('هل أنت متأكد من رغبتك في سحب جميع البيانات؟ قد تستغرق العملية عدة دقائق.')) {
        return;
    }
    
    const btn = this;
    const progressAlert = document.getElementById('progressAlert');
    const progressBar = document.getElementById('progressBar');
    const progressMessage = document.getElementById('progressMessage');
    
    btn.disabled = true;
    progressAlert.classList.remove('d-none');
    
    fetch('ajax/initial_fetch.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                progressBar.style.width = '100%';
                progressBar.textContent = '100%';
                progressMessage.innerHTML = '<strong class="text-success">✓ تم السحب بنجاح!</strong>';
                
                setTimeout(() => {
                    location.reload();
                }, 2000);
            } else {
                progressMessage.innerHTML = '<strong class="text-danger">✗ فشل السحب: ' + data.message + '</strong>';
                btn.disabled = false;
            }
        })
        .catch(error => {
            progressMessage.innerHTML = '<strong class="text-danger">✗ خطأ: ' + error + '</strong>';
            btn.disabled = false;
        });
});

// زر التحديث التلقائي
document.getElementById('refreshBtn').addEventListener('click', function() {
    fetch('ajax/check_updates.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('تم تشغيل التحديث التلقائي بنجاح');
                location.reload();
            }
        });
});

// أزرار التحديث اليدوي
document.querySelectorAll('.manual-update').forEach(btn => {
    btn.addEventListener('click', function() {
        const type = this.dataset.type;
        const btnElement = this;
        
        btnElement.disabled = true;
        btnElement.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري...';
        
        fetch('ajax/manual_update.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'type=' + type
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('تم التحديث بنجاح: ' + data.message);
                location.reload();
            } else {
                alert('فشل التحديث: ' + data.message);
                btnElement.disabled = false;
                btnElement.innerHTML = '<i class="bi bi-play-fill"></i> تشغيل';
            }
        });
    });
});

// تحديث تلقائي للمباريات الجارية كل 30 ثانية
setInterval(() => {
    fetch('ajax/update_live.php')
        .then(response => response.json())
        .then(data => {
            if (data.updated) {
                location.reload();
            }
        });
}, 30000);
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>