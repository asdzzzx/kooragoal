<?php
// تفاصيل المباراة
// admin/match_details.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();
$match_id = $_GET['id'] ?? 0;

$fixture = $db->queryOne(
    "SELECT * FROM fixtures WHERE api_id = :id",
    ['id' => $match_id]
);

if (!$fixture) {
    header('Location: fixtures.php');
    exit;
}

$events = $db->query(
    "SELECT * FROM events WHERE fixture_id = :id ORDER BY time_elapsed ASC",
    ['id' => $match_id]
);

$stats = $db->query(
    "SELECT * FROM statistics WHERE fixture_id = :id",
    ['id' => $match_id]
);

$lineups = $db->query(
    "SELECT * FROM lineups WHERE fixture_id = :id",
    ['id' => $match_id]
);

$pageTitle = 'تفاصيل المباراة';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-info-circle"></i> تفاصيل المباراة
                </h1>
                <div>
                    <button class="btn btn-primary" onclick="location.reload()">
                        <i class="bi bi-arrow-clockwise"></i> تحديث
                    </button>
                    <a href="fixtures.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-right"></i> رجوع
                    </a>
                </div>
            </div>
            
            <!-- معلومات المباراة -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <img src="<?php echo $fixture['league_logo']; ?>" width="25" class="me-2" alt="">
                            <?php echo $fixture['league_name']; ?> - <?php echo $fixture['league_round']; ?>
                        </div>
                        <span class="badge 
                            <?php echo in_array($fixture['status_short'], ['1H', '2H']) ? 'bg-danger blink' : 'bg-light text-dark'; ?>">
                            <?php echo getMatchStatusAr($fixture['status_short']); ?>
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row align-items-center text-center">
                        <div class="col-md-4">
                            <img src="<?php echo $fixture['home_team_logo']; ?>" width="80" class="mb-3" alt="">
                            <h4><?php echo $fixture['home_team_name']; ?></h4>
                        </div>
                        
                        <div class="col-md-4">
                            <h1 class="display-3 mb-0">
                                <span class="text-primary"><?php echo $fixture['goals_home'] ?? '-'; ?></span>
                                <span class="text-muted">:</span>
                                <span class="text-danger"><?php echo $fixture['goals_away'] ?? '-'; ?></span>
                            </h1>
                            <?php if ($fixture['score_halftime_home'] !== null): ?>
                            <p class="text-muted">
                                الشوط الأول: <?php echo $fixture['score_halftime_home']; ?> - <?php echo $fixture['score_halftime_away']; ?>
                            </p>
                            <?php endif; ?>
                            <p class="text-muted">
                                <i class="bi bi-calendar"></i> 
                                <?php echo formatDate($fixture['date'], 'Y-m-d H:i'); ?>
                            </p>
                            <?php if ($fixture['venue_name']): ?>
                            <p class="text-muted">
                                <i class="bi bi-geo-alt"></i> 
                                <?php echo $fixture['venue_name']; ?>, <?php echo $fixture['venue_city']; ?>
                            </p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="col-md-4">
                            <img src="<?php echo $fixture['away_team_logo']; ?>" width="80" class="mb-3" alt="">
                            <h4><?php echo $fixture['away_team_name']; ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- الأحداث -->
            <?php if (!empty($events)): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-list-ul"></i> أحداث المباراة</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($events as $event): ?>
                    <div class="mb-3 pb-3 border-bottom">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-secondary me-2"><?php echo $event['time_elapsed']; ?>'</span>
                            <img src="<?php echo $event['team_logo']; ?>" width="25" class="me-2" alt="">
                            
                            <?php if ($event['type'] === 'Goal'): ?>
                                <i class="bi bi-trophy-fill text-success fs-4 me-2"></i>
                            <?php elseif ($event['type'] === 'Card'): ?>
                                <?php if ($event['detail'] === 'Yellow Card'): ?>
                                    <div class="bg-warning" style="width: 20px; height: 25px; margin-right: 8px;"></div>
                                <?php else: ?>
                                    <div class="bg-danger" style="width: 20px; height: 25px; margin-right: 8px;"></div>
                                <?php endif; ?>
                            <?php elseif ($event['type'] === 'subst'): ?>
                                <i class="bi bi-arrow-left-right text-primary fs-4 me-2"></i>
                            <?php endif; ?>
                            
                            <div>
                                <strong><?php echo $event['player_name']; ?></strong>
                                <?php if ($event['assist_name']): ?>
                                    <small class="text-muted">(<?php echo $event['assist_name']; ?>)</small>
                                <?php endif; ?>
                                <br>
                                <small class="text-muted"><?php echo $event['detail']; ?></small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- الإحصائيات -->
            <?php if (!empty($stats)): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-graph-up"></i> الإحصائيات</h5>
                </div>
                <div class="card-body">
                    <?php 
                    $home_stats = $stats[0] ?? null;
                    $away_stats = $stats[1] ?? null;
                    
                    if ($home_stats && $away_stats):
                        $statsItems = [
                            ['label' => 'التسديدات على المرمى', 'key' => 'shots_on_goal'],
                            ['label' => 'إجمالي التسديدات', 'key' => 'total_shots'],
                            ['label' => 'الأخطاء', 'key' => 'fouls'],
                            ['label' => 'الركنيات', 'key' => 'corner_kicks'],
                            ['label' => 'التسلل', 'key' => 'offsides'],
                            ['label' => 'الاستحواذ', 'key' => 'ball_possession'],
                            ['label' => 'البطاقات الصفراء', 'key' => 'yellow_cards'],
                            ['label' => 'البطاقات الحمراء', 'key' => 'red_cards'],
                            ['label' => 'التمريرات الدقيقة', 'key' => 'passes_accurate'],
                        ];
                        
                        foreach ($statsItems as $item):
                            $homeVal = $home_stats[$item['key']] ?? 0;
                            $awayVal = $away_stats[$item['key']] ?? 0;
                    ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <strong><?php echo $homeVal; ?></strong>
                            <span class="text-muted"><?php echo $item['label']; ?></span>
                            <strong><?php echo $awayVal; ?></strong>
                        </div>
                        <div class="progress" style="height: 20px;">
                            <?php
                            $total = is_numeric($homeVal) && is_numeric($awayVal) ? ($homeVal + $awayVal) : 100;
                            $homePercent = $total > 0 ? ($homeVal / $total * 100) : 50;
                            $awayPercent = 100 - $homePercent;
                            ?>
                            <div class="progress-bar bg-primary" style="width: <?php echo $homePercent; ?>%"></div>
                            <div class="progress-bar bg-danger" style="width: <?php echo $awayPercent; ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- التشكيل -->
            <?php if (!empty($lineups)): ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-people"></i> التشكيلات</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php foreach ($lineups as $lineup): 
                            $players = json_decode($lineup['players'], true);
                            $subs = json_decode($lineup['substitutes'], true);
                        ?>
                        <div class="col-md-6">
                            <h5 class="text-center mb-3">
                                <img src="<?php echo $lineup['team_logo']; ?>" width="30" class="me-2" alt="">
                                <?php echo $lineup['team_name']; ?>
                                <span class="badge bg-secondary ms-2"><?php echo $lineup['formation']; ?></span>
                            </h5>
                            
                            <h6 class="mt-3">التشكيل الأساسي:</h6>
                            <ul class="list-group list-group-flush">
                                <?php if (is_array($players)): foreach ($players as $p): ?>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>
                                        <span class="badge bg-primary me-2"><?php echo $p['player']['number'] ?? ''; ?></span>
                                        <?php echo $p['player']['name'] ?? ''; ?>
                                    </span>
                                    <small class="text-muted"><?php echo $p['player']['pos'] ?? ''; ?></small>
                                </li>
                                <?php endforeach; endif; ?>
                            </ul>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>