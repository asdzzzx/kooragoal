<?php
// المباريات الجارية
// admin/live_fixtures.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

// جلب المباريات الجارية
$liveFixtures = $db->query(
    "SELECT * FROM fixtures 
     WHERE is_live = 1 
     ORDER BY date ASC"
);

$pageTitle = 'المباريات الجارية';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-broadcast text-danger"></i> المباريات الجارية
                    <span class="badge bg-danger blink ms-2">LIVE</span>
                </h1>
                <div class="btn-toolbar">
                    <button type="button" class="btn btn-success" id="refreshLiveBtn">
                        <i class="bi bi-arrow-clockwise"></i> تحديث الآن
                    </button>
                    <span class="badge bg-info ms-2 fs-6" id="autoRefreshTimer">
                        التحديث التلقائي بعد: 25s
                    </span>
                </div>
            </div>
            
            <?php if (empty($liveFixtures)): ?>
                <div class="alert alert-info text-center">
                    <i class="bi bi-info-circle" style="font-size: 3rem;"></i>
                    <h4 class="mt-3">لا توجد مباريات جارية حالياً</h4>
                    <p>سيتم التحديث تلقائياً كل 25 ثانية للبحث عن مباريات جديدة</p>
                </div>
            <?php else: ?>
                <!-- عدد المباريات الجارية -->
                <div class="alert alert-success">
                    <strong><i class="bi bi-broadcast"></i> يوجد <?php echo count($liveFixtures); ?> مباراة جارية الآن</strong>
                </div>
                
                <!-- المباريات -->
                <div class="row">
                    <?php foreach ($liveFixtures as $fixture): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card shadow-sm border-danger live-match-card" 
                             data-id="<?php echo $fixture['api_id']; ?>">
                            <div class="card-header bg-danger text-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <img src="<?php echo $fixture['league_logo']; ?>" 
                                             width="20" class="me-2" alt="">
                                        <strong><?php echo $fixture['league_name']; ?></strong>
                                    </div>
                                    <span class="badge bg-light text-danger blink">
                                        <?php echo getMatchStatusAr($fixture['status_short']); ?>
                                        <?php if ($fixture['status_elapsed']): ?>
                                            - <?php echo $fixture['status_elapsed']; ?>'
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="card-body">
                                <!-- الفريق المضيف -->
                                <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo $fixture['home_team_logo']; ?>" 
                                             width="40" class="me-3" alt="">
                                        <h5 class="mb-0"><?php echo $fixture['home_team_name']; ?></h5>
                                    </div>
                                    <h2 class="mb-0 text-primary">
                                        <?php echo $fixture['goals_home'] ?? '0'; ?>
                                    </h2>
                                </div>
                                
                                <!-- الفريق الضيف -->
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo $fixture['away_team_logo']; ?>" 
                                             width="40" class="me-3" alt="">
                                        <h5 class="mb-0"><?php echo $fixture['away_team_name']; ?></h5>
                                    </div>
                                    <h2 class="mb-0 text-primary">
                                        <?php echo $fixture['goals_away'] ?? '0'; ?>
                                    </h2>
                                </div>
                                
                                <!-- معلومات إضافية -->
                                <?php if ($fixture['score_halftime_home'] !== null): ?>
                                <div class="text-center mt-3 pt-3 border-top">
                                    <small class="text-muted">
                                        الشوط الأول: 
                                        <?php echo $fixture['score_halftime_home']; ?> - <?php echo $fixture['score_halftime_away']; ?>
                                    </small>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="card-footer">
                                <div class="btn-group w-100">
                                    <a href="match_details.php?id=<?php echo $fixture['api_id']; ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i> التفاصيل
                                    </a>
                                    <button class="btn btn-sm btn-outline-success update-live-match" 
                                            data-id="<?php echo $fixture['api_id']; ?>">
                                        <i class="bi bi-arrow-clockwise"></i> تحديث
                                    </button>
                                    <a href="match_events.php?id=<?php echo $fixture['api_id']; ?>" 
                                       class="btn btn-sm btn-outline-info">
                                        <i class="bi bi-list-ul"></i> الأحداث
                                    </a>
                                    <a href="match_stats.php?id=<?php echo $fixture['api_id']; ?>" 
                                       class="btn btn-sm btn-outline-warning">
                                        <i class="bi bi-graph-up"></i> الإحصائيات
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<style>
.live-match-card {
    transition: transform 0.2s;
}
.live-match-card:hover {
    transform: translateY(-5px);
}
.blink {
    animation: blinker 1.5s linear infinite;
}
@keyframes blinker {
    50% { opacity: 0.5; }
}
</style>

<script>
let autoRefreshInterval;
let countdownInterval;
let timeLeft = 25;

// تحديث يدوي
document.getElementById('refreshLiveBtn').addEventListener('click', function() {
    refreshLiveMatches();
});

// تحديث مباراة واحدة
document.querySelectorAll('.update-live-match').forEach(btn => {
    btn.addEventListener('click', function() {
        const matchId = this.dataset.id;
        const btnElement = this;
        
        btnElement.disabled = true;
        btnElement.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        
        fetch('ajax/update_match.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'match_id=' + matchId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showError(data.message);
                btnElement.disabled = false;
                btnElement.innerHTML = '<i class="bi bi-arrow-clockwise"></i> تحديث';
            }
        });
    });
});

// تحديث جميع المباريات الجارية
function refreshLiveMatches() {
    fetch('ajax/update_live.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data.updated) {
                location.reload();
            }
        });
}

// العد التنازلي للتحديث التلقائي
function updateCountdown() {
    document.getElementById('autoRefreshTimer').textContent = 
        `التحديث التلقائي بعد: ${timeLeft}s`;
    
    if (timeLeft <= 0) {
        timeLeft = 25;
        refreshLiveMatches();
    } else {
        timeLeft--;
    }
}

// بدء التحديث التلقائي
autoRefreshInterval = setInterval(refreshLiveMatches, 25000);
countdownInterval = setInterval(updateCountdown, 1000);

// إيقاف التحديث عند مغادرة الصفحة
window.addEventListener('beforeunload', function() {
    clearInterval(autoRefreshInterval);
    clearInterval(countdownInterval);
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>