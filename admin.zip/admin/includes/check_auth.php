<?php
// التحقق من صلاحية الجلسة
// admin/includes/check_auth.php

require_once __DIR__ . '/../../config/config.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    redirect(ADMIN_PATH . '/login.php');
}

// التحقق من مدة الجلسة
if (isset($_SESSION['last_activity'])) {
    $inactive = time() - $_SESSION['last_activity'];
    
    if ($inactive > SESSION_LIFETIME) {
        session_unset();
        session_destroy();
        redirect(ADMIN_PATH . '/login.php?timeout=1');
    }
}

// تحديث آخر نشاط
$_SESSION['last_activity'] = time();

// دالة للتحقق من الصلاحيات
function hasPermission($requiredRole = 'admin') {
    $roles = ['editor' => 1, 'admin' => 2, 'super_admin' => 3];
    
    $userRole = $_SESSION['admin_role'] ?? 'editor';
    
    $userLevel = $roles[$userRole] ?? 0;
    $requiredLevel = $roles[$requiredRole] ?? 0;
    
    return $userLevel >= $requiredLevel;
}
?>