<nav class="col-md-3 col-lg-2 d-md-block sidebar">
    <div class="sidebar-brand">
        <i class="bi bi-broadcast"></i>
        <?php echo SITE_NAME; ?>
    </div>
    
    <div class="position-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo ADMIN_PATH; ?>/index.php">
                    <i class="bi bi-speedometer2"></i>
                    لوحة التحكم
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/fixtures.php">
                    <i class="bi bi-calendar-event"></i>
                    المباريات
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/live_fixtures.php">
                    <i class="bi bi-broadcast"></i>
                    المباريات الجارية
                    <span class="badge bg-danger ms-2">LIVE</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/leagues.php">
                    <i class="bi bi-trophy"></i>
                    الدوريات
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/teams.php">
                    <i class="bi bi-people"></i>
                    الفرق
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/standings.php">
                    <i class="bi bi-bar-chart"></i>
                    الترتيب
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/scorers.php">
                    <i class="bi bi-award"></i>
                    الهدافين
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/statistics.php">
                    <i class="bi bi-graph-up"></i>
                    الإحصائيات
                </a>
            </li>
            
            <li class="nav-item mt-3">
                <h6 class="text-white-50 text-uppercase px-3 mb-2" style="font-size: 0.75rem;">
                    الإدارة
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/updates.php">
                    <i class="bi bi-arrow-clockwise"></i>
                    التحديثات
                </a>
            </li>
            
            <?php if (isSuperAdmin()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/admins.php">
                    <i class="bi bi-person-badge"></i>
                    المسؤولين
                </a>
            </li>
            <?php endif; ?>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/logs.php">
                    <i class="bi bi-list-ul"></i>
                    السجلات
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo ADMIN_PATH; ?>/settings.php">
                    <i class="bi bi-gear"></i>
                    الإعدادات
                </a>
            </li>
            
            <li class="nav-item mt-4">
                <a class="nav-link text-danger" href="<?php echo ADMIN_PATH; ?>/logout.php">
                    <i class="bi bi-box-arrow-left"></i>
                    تسجيل الخروج
                </a>
            </li>
        </ul>
    </div>
</nav>