<!-- Footer -->
    <footer class="text-center py-4 mt-5" style="background-color: #f8f9fc; border-top: 1px solid #e3e6f0; margin-right: 240px;">
        <div class="container">
            <p class="text-muted mb-0">
                © <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - جميع الحقوق محفوظة
            </p>
            <small class="text-muted">
                النسخة 1.0 | تم التطوير بواسطة Yacine TV
            </small>
        </div>
    </footer>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.0/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.0/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- Custom Scripts -->
    <script>
        // تفعيل DataTables
        $(document).ready(function() {
            $('.datatable').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.0/i18n/ar.json'
                },
                pageLength: 25,
                order: [[0, 'desc']]
            });
        });
        
        // تأكيد الحذف
        function confirmDelete(message) {
            return confirm(message || 'هل أنت متأكد من رغبتك في الحذف؟');
        }
        
        // إظهار رسالة نجاح
        function showSuccess(message) {
            const alert = `
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle-fill"></i> ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
            $('.container-fluid').prepend(alert);
            
            setTimeout(() => {
                $('.alert').fadeOut();
            }, 3000);
        }
        
        // إظهار رسالة خطأ
        function showError(message) {
            const alert = `
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i> ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
            $('.container-fluid').prepend(alert);
            
            setTimeout(() => {
                $('.alert').fadeOut();
            }, 5000);
        }
        
        // AJAX Error Handler
        $(document).ajaxError(function(event, jqxhr, settings, thrownError) {
            console.error('AJAX Error:', thrownError);
            showError('حدث خطأ في الاتصال بالخادم');
        });
    </script>
</body>
</html>