<?php
// حذف مباراة
// admin/ajax/delete_match.php

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/Database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    jsonResponse(false, 'غير مصرح');
}

if (!hasPermission('admin')) {
    jsonResponse(false, 'ليس لديك صلاحية الحذف');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'طريقة غير مسموحة');
}

$id = $_POST['id'] ?? '';

if (empty($id)) {
    jsonResponse(false, 'معرف المباراة مطلوب');
}

try {
    $db = Database::getInstance();
    
    // جلب معلومات المباراة قبل الحذف
    $fixture = $db->queryOne("SELECT * FROM fixtures WHERE id = :id", ['id' => $id]);
    
    if (!$fixture) {
        jsonResponse(false, 'المباراة غير موجودة');
    }
    
    // بدء معاملة
    $db->beginTransaction();
    
    try {
        // حذف الإحصائيات
        $db->delete('statistics', 'fixture_id = :fixture_id', ['fixture_id' => $fixture['api_id']]);
        
        // حذف الأحداث
        $db->delete('events', 'fixture_id = :fixture_id', ['fixture_id' => $fixture['api_id']]);
        
        // حذف التشكيلات
        $db->delete('lineups', 'fixture_id = :fixture_id', ['fixture_id' => $fixture['api_id']]);
        
        // حذف المباراة
        $db->delete('fixtures', 'id = :id', ['id' => $id]);
        
        // تأكيد المعاملة
        $db->commit();
        
        // تسجيل العملية
        $db->insert('logs', [
            'admin_id' => $_SESSION['admin_id'],
            'action_type' => 'delete_match',
            'action_description' => "حذف مباراة: {$fixture['home_team_name']} vs {$fixture['away_team_name']}",
            'ip_address' => getClientIP(),
            'status' => 'success'
        ]);
        
        jsonResponse(true, 'تم حذف المباراة بنجاح');
        
    } catch (Exception $e) {
        // إلغاء المعاملة في حالة الخطأ
        $db->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    jsonResponse(false, 'خطأ: ' . $e->getMessage());
}
?>