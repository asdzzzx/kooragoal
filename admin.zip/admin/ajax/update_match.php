<?php
// تحديث مباراة واحدة
// admin/ajax/update_match.php

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../../classes/ApiFootball.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    jsonResponse(false, 'غير مصرح');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'طريقة غير مسموحة');
}

$matchId = $_POST['match_id'] ?? '';

if (empty($matchId)) {
    jsonResponse(false, 'معرف المباراة مطلوب');
}

try {
    $api = new ApiFootball();
    $db = Database::getInstance();
    
    // جلب بيانات المباراة
    $result = $api->makeRequest('/fixtures', ['id' => $matchId]);
    
    if (!$result['success']) {
        jsonResponse(false, 'فشل جلب بيانات المباراة');
    }
    
    // تحديث المباراة
    $api->saveDailyFixtures($result['data']);
    
    // جلب الإحصائيات والأحداث إذا كانت المباراة جارية أو انتهت
    $fixture = $result['data'][0]['fixture'] ?? null;
    if ($fixture && in_array($fixture['status']['short'], ['1H', '2H', 'ET', 'FT'])) {
        $api->getFixtureStatistics($matchId);
        $api->getFixtureEvents($matchId);
    }
    
    // تسجيل العملية
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'],
        'action_type' => 'update_match',
        'action_description' => "تحديث مباراة رقم {$matchId}",
        'ip_address' => getClientIP(),
        'status' => 'success'
    ]);
    
    jsonResponse(true, 'تم تحديث المباراة بنجاح');
    
} catch (Exception $e) {
    jsonResponse(false, 'خطأ: ' . $e->getMessage());
}
?>