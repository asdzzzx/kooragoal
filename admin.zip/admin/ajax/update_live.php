<?php
// تحديث المباريات الجارية تلقائياً
// admin/ajax/update_live.php

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../../classes/ApiFootball.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $api = new ApiFootball();
    $result = $api->getLiveFixtures();
    
    jsonResponse(true, 'تم التحديث', [
        'updated' => $result['success'],
        'count' => $result['count'] ?? 0
    ]);
    
} catch (Exception $e) {
    jsonResponse(false, 'خطأ: ' . $e->getMessage());
}
?>