<?php
// فحص وتنفيذ التحديثات التلقائية
// admin/ajax/check_updates.php

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../../classes/Scheduler.php';

header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    jsonResponse(false, 'غير مصرح');
}

try {
    $scheduler = new Scheduler();
    $results = $scheduler->checkAllUpdates();
    
    $count = count($results);
    
    jsonResponse(true, "تم فحص وتنفيذ {$count} تحديث", $results);
    
} catch (Exception $e) {
    jsonResponse(false, 'خطأ: ' . $e->getMessage());
}
?>