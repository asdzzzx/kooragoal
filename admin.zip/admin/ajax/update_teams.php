<?php
// تحديث بيانات الفرق
// admin/ajax/update_teams.php

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../../classes/ApiFootball.php';

header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    jsonResponse(false, 'غير مصرح');
}

try {
    $api = new ApiFootball();
    $db = Database::getInstance();
    
    // تسجيل بداية العملية
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'],
        'action_type' => 'update_teams',
        'action_description' => 'بدء تحديث بيانات الفرق',
        'ip_address' => getClientIP(),
        'status' => 'success'
    ]);
    
    // جلب الفرق من الدوريات المحددة
    $result = $api->getTeamsFromSelectedLeagues();
    
    if ($result['success']) {
        // تسجيل النتائج
        $db->insert('logs', [
            'admin_id' => $_SESSION['admin_id'],
            'action_type' => 'update_teams_completed',
            'action_description' => "تم تحديث {$result['count']} فريق",
            'ip_address' => getClientIP(),
            'status' => 'success'
        ]);
        
        jsonResponse(true, "تم تحديث الفرق بنجاح", [
            'count' => $result['count']
        ]);
    } else {
        jsonResponse(false, $result['error'] ?? 'فشل تحديث الفرق');
    }
    
} catch (Exception $e) {
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'] ?? null,
        'action_type' => 'update_teams_error',
        'action_description' => 'خطأ في تحديث الفرق: ' . $e->getMessage(),
        'ip_address' => getClientIP(),
        'status' => 'failed'
    ]);
    
    jsonResponse(false, 'حدث خطأ: ' . $e->getMessage());
}
?>