<?php
// تنفيذ تحديث يدوي لنوع معين
// admin/ajax/manual_update.php

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../../classes/Scheduler.php';

header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    jsonResponse(false, 'غير مصرح');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'طريقة غير مسموحة');
}

$type = $_POST['type'] ?? '';

if (empty($type)) {
    jsonResponse(false, 'نوع التحديث مطلوب');
}

try {
    $scheduler = new Scheduler();
    $db = Database::getInstance();
    
    // تسجيل العملية
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'],
        'action_type' => 'manual_update',
        'action_description' => "تحديث يدوي: {$type}",
        'ip_address' => getClientIP(),
        'status' => 'success'
    ]);
    
    $result = $scheduler->runManualUpdate($type);
    
    if ($result['success']) {
        jsonResponse(true, $result['message'], ['count' => $result['count'] ?? 0]);
    } else {
        jsonResponse(false, $result['message']);
    }
    
} catch (Exception $e) {
    jsonResponse(false, 'خطأ: ' . $e->getMessage());
}
?>