<?php
// سحب جميع البيانات للمرة الأولى
// admin/ajax/initial_fetch.php

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../../classes/Scheduler.php';

header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    jsonResponse(false, 'غير مصرح');
}

try {
    $scheduler = new Scheduler();
    $db = Database::getInstance();
    
    // تسجيل بداية العملية
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'],
        'action_type' => 'initial_fetch',
        'action_description' => 'بدء عملية السحب الشامل للبيانات',
        'ip_address' => getClientIP(),
        'status' => 'success'
    ]);
    
    // تنفيذ السحب الشامل
    $results = $scheduler->initialDataFetch();
    
    // حساب النتائج
    $totalSuccess = 0;
    $totalFailed = 0;
    $details = [];
    
    foreach ($results as $key => $result) {
        if (isset($result['success']) && $result['success']) {
            $totalSuccess++;
            $details[$key] = "نجح - " . ($result['count'] ?? 0) . " سجل";
        } else {
            $totalFailed++;
            $details[$key] = "فشل - " . ($result['error'] ?? 'خطأ غير معروف');
        }
    }
    
    // تسجيل النتائج
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'],
        'action_type' => 'initial_fetch_completed',
        'action_description' => "اكتملت عملية السحب الشامل - نجح: {$totalSuccess}, فشل: {$totalFailed}",
        'ip_address' => getClientIP(),
        'status' => $totalFailed > 0 ? 'warning' : 'success'
    ]);
    
    jsonResponse(true, "تم سحب البيانات بنجاح", [
        'total_success' => $totalSuccess,
        'total_failed' => $totalFailed,
        'details' => $details
    ]);
    
} catch (Exception $e) {
    $db->insert('logs', [
        'admin_id' => $_SESSION['admin_id'] ?? null,
        'action_type' => 'initial_fetch_error',
        'action_description' => 'خطأ في عملية السحب الشامل: ' . $e->getMessage(),
        'ip_address' => getClientIP(),
        'status' => 'failed'
    ]);
    
    jsonResponse(false, 'حدث خطأ: ' . $e->getMessage());
}
?>