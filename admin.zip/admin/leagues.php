<?php
// إدارة الدوريات
// admin/leagues.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

// الفلترة
$country = $_GET['country'] ?? '';
$search = $_GET['search'] ?? '';

// بناء الاستعلام
$where = "1=1";
$params = [];

if (!empty($country)) {
    $where .= " AND country = :country";
    $params['country'] = $country;
}

if (!empty($search)) {
    $where .= " AND name LIKE :search";
    $params['search'] = "%{$search}%";
}

// جلب الدوريات
$leagues = $db->query(
    "SELECT * FROM leagues WHERE {$where} ORDER BY country, name",
    $params
);

// جلب الدول للفلتر
$countries = $db->query(
    "SELECT DISTINCT country FROM leagues WHERE country IS NOT NULL ORDER BY country"
);

$pageTitle = 'إدارة الدوريات';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-trophy"></i> إدارة الدوريات
                </h1>
                <div class="btn-toolbar">
                    <button type="button" class="btn btn-primary" id="fetchLeaguesBtn">
                        <i class="bi bi-cloud-download"></i> جلب الدوريات
                    </button>
                </div>
            </div>
            
            <!-- الفلاتر -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">الدولة</label>
                            <select class="form-select" name="country">
                                <option value="">جميع الدول</option>
                                <?php foreach ($countries as $c): ?>
                                <option value="<?php echo $c['country']; ?>"
                                        <?php echo $country === $c['country'] ? 'selected' : ''; ?>>
                                    <?php echo $c['country']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">البحث</label>
                            <input type="text" class="form-control" name="search" 
                                   value="<?php echo htmlspecialchars($search); ?>" 
                                   placeholder="اسم الدوري...">
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> بحث
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- جدول الدوريات -->
            <div class="card">
                <div class="card-header">
                    <h6 class="m-0">
                        عدد الدوريات: <?php echo count($leagues); ?>
                    </h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover datatable">
                            <thead>
                                <tr>
                                    <th>الشعار</th>
                                    <th>الاسم</th>
                                    <th>النوع</th>
                                    <th>الدولة</th>
                                    <th>الموسم</th>
                                    <th>الحالة</th>
                                    <th>إجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($leagues as $league): ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo $league['logo']; ?>" width="30" alt="">
                                    </td>
                                    <td>
                                        <strong><?php echo $league['name']; ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary">
                                            <?php echo $league['type'] ?? 'دوري'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($league['country_flag']): ?>
                                        <img src="<?php echo $league['country_flag']; ?>" width="20" class="me-1" alt="">
                                        <?php endif; ?>
                                        <?php echo $league['country']; ?>
                                    </td>
                                    <td><?php echo $league['season']; ?></td>
                                    <td>
                                        <?php if ($league['is_current']): ?>
                                            <span class="badge bg-success">جاري</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">منتهي</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="standings.php?league=<?php echo $league['api_id']; ?>&season=<?php echo $league['season']; ?>" 
                                               class="btn btn-info" title="الترتيب">
                                                <i class="bi bi-bar-chart"></i>
                                            </a>
                                            <a href="scorers.php?league=<?php echo $league['api_id']; ?>&season=<?php echo $league['season']; ?>" 
                                               class="btn btn-warning" title="الهدافين">
                                                <i class="bi bi-award"></i>
                                            </a>
                                            <a href="/league/<?php echo $league['api_id']; ?>" 
                                               class="btn btn-success" target="_blank" title="عرض عام">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.getElementById('fetchLeaguesBtn').addEventListener('click', function() {
    if (!confirm('هل تريد جلب جميع الدوريات من API؟')) return;
    
    const btn = this;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري الجلب...';
    
    fetch('ajax/fetch_leagues.php', {method: 'POST'})
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccess(data.message);
                setTimeout(() => location.reload(), 1500);
            } else {
                showError(data.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-cloud-download"></i> جلب الدوريات';
            }
        });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>