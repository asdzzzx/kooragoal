<?php
// إدارة الفرق (مصلح)
// admin/teams.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$country = isset($_GET['country']) ? clean($_GET['country']) : '';
$search = isset($_GET['search']) ? clean($_GET['search']) : '';

$where = "1=1";
$params = [];

if (!empty($country)) {
    $where .= " AND country = :country";
    $params['country'] = $country;
}

if (!empty($search)) {
    $where .= " AND name LIKE :search";
    $params['search'] = "%{$search}%";
}

$teams = $db->query(
    "SELECT * FROM teams WHERE {$where} ORDER BY name LIMIT 100",
    $params
);

$countries = $db->query(
    "SELECT DISTINCT country FROM teams WHERE country IS NOT NULL ORDER BY country"
);

$pageTitle = 'إدارة الفرق';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-people"></i> إدارة الفرق
                </h1>
                <div class="btn-toolbar">
                    <button type="button" class="btn btn-primary" id="updateTeamsBtn">
                        <i class="bi bi-arrow-clockwise"></i> تحديث الفرق
                    </button>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">الدولة</label>
                            <select class="form-select" name="country">
                                <option value="">جميع الدول</option>
                                <?php if (!empty($countries)): ?>
                                    <?php foreach ($countries as $c): ?>
                                    <option value="<?php echo htmlspecialchars($c['country']); ?>"
                                            <?php echo $country === $c['country'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($c['country']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">البحث</label>
                            <input type="text" class="form-control" name="search" 
                                   value="<?php echo htmlspecialchars($search); ?>" 
                                   placeholder="اسم الفريق...">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> بحث
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h6 class="m-0">
                        عدد الفرق: <?php echo count($teams); ?>
                        <?php if (count($teams) >= 100): ?>
                            <span class="badge bg-warning">عرض أول 100 فريق فقط</span>
                        <?php endif; ?>
                    </h6>
                </div>
                <div class="card-body">
                    <?php if (empty($teams)): ?>
                        <div class="alert alert-info text-center">
                            <i class="bi bi-info-circle"></i> 
                            لا توجد فرق. اضغط على "تحديث الفرق" لجلب البيانات.
                        </div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>الشعار</th>
                                    <th>الاسم</th>
                                    <th>الرمز</th>
                                    <th>الدولة</th>
                                    <th>التأسيس</th>
                                    <th>الملعب</th>
                                    <th>إجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($teams as $team): ?>
                                <tr>
                                    <td>
                                        <?php if (!empty($team['logo'])): ?>
                                        <img src="<?php echo htmlspecialchars($team['logo']); ?>" 
                                             width="30" alt="<?php echo htmlspecialchars($team['name']); ?>"
                                             onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2230%22 height=%2230%22%3E%3Crect fill=%22%23ddd%22 width=%2230%22 height=%2230%22/%3E%3C/svg%3E'">
                                        <?php else: ?>
                                        <div style="width:30px;height:30px;background:#ddd;border-radius:50%;"></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($team['name']); ?></strong>
                                    </td>
                                    <td>
                                        <?php echo !empty($team['code']) ? htmlspecialchars($team['code']) : '-'; ?>
                                    </td>
                                    <td>
                                        <?php echo !empty($team['country']) ? htmlspecialchars($team['country']) : '-'; ?>
                                    </td>
                                    <td>
                                        <?php echo !empty($team['founded']) ? htmlspecialchars($team['founded']) : '-'; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($team['venue_name'])): ?>
                                            <small>
                                                <i class="bi bi-stadium"></i>
                                                <?php echo htmlspecialchars($team['venue_name']); ?>
                                            </small>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="/team/<?php echo $team['api_id']; ?>" 
                                           class="btn btn-sm btn-info" target="_blank"
                                           title="عرض صفحة الفريق">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.getElementById('updateTeamsBtn')?.addEventListener('click', function() {
    if (!confirm('هل تريد تحديث بيانات الفرق؟ قد يستغرق بضع دقائق.')) {
        return;
    }
    
    const btn = this;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري التحديث...';
    
    fetch('ajax/update_teams.php', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess(data.message + ' - تم تحديث ' + data.count + ' فريق');
            setTimeout(() => location.reload(), 2000);
        } else {
            showError(data.message || 'فشل التحديث');
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> تحديث الفرق';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showError('حدث خطأ أثناء التحديث');
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> تحديث الفرق';
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>