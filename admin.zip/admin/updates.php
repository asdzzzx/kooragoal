<?php
// إدارة التحديثات
// admin/updates.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Scheduler.php';

$db = Database::getInstance();
$scheduler = new Scheduler();

$updates = $scheduler->getUpdateStatus();

$pageTitle = 'إدارة التحديثات';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-arrow-clockwise"></i> إدارة التحديثات
                </h1>
                <button class="btn btn-primary" onclick="checkAllUpdates()">
                    <i class="bi bi-play-fill"></i> تشغيل جميع التحديثات
                </button>
            </div>
            
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i>
                <strong>ملاحظة:</strong> التحديثات تعمل تلقائياً حسب الجدول الزمني المحدد. يمكنك تشغيلها يدوياً في أي وقت.
            </div>
            
            <div class="row mb-4">
                <?php 
                $types = [
                    'daily_fixtures' => ['name' => 'مباريات اليوم', 'icon' => 'calendar-event', 'color' => 'primary'],
                    'live_fixtures' => ['name' => 'المباريات الجارية', 'icon' => 'broadcast', 'color' => 'danger'],
                    'fixtures_statistics' => ['name' => 'الإحصائيات', 'icon' => 'graph-up', 'color' => 'info'],
                    'fixtures_events' => ['name' => 'الأحداث', 'icon' => 'list-ul', 'color' => 'warning'],
                    'fixtures_lineups' => ['name' => 'التشكيلات', 'icon' => 'people', 'color' => 'success'],
                    'leagues_standings' => ['name' => 'الترتيب', 'icon' => 'bar-chart', 'color' => 'primary'],
                    'leagues_scorers' => ['name' => 'الهدافين', 'icon' => 'award', 'color' => 'warning'],
                ];
                
                foreach ($updates as $update):
                    $type = $types[$update['update_type']] ?? ['name' => $update['update_type'], 'icon' => 'arrow-clockwise', 'color' => 'secondary'];
                ?>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0">
                                    <i class="bi bi-<?php echo $type['icon']; ?> text-<?php echo $type['color']; ?>"></i>
                                    <?php echo $type['name']; ?>
                                </h5>
                                <?php if ($update['status'] === 'success'): ?>
                                    <span class="badge bg-success">نجح</span>
                                <?php elseif ($update['status'] === 'failed'): ?>
                                    <span class="badge bg-danger">فشل</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">جاري</span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted">آخر تحديث:</small>
                                <div><?php echo formatDate($update['last_update']); ?></div>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted">عدد السجلات:</small>
                                <div><strong><?php echo number_format($update['records_count']); ?></strong></div>
                            </div>
                            
                            <?php if ($update['error_message']): ?>
                            <div class="alert alert-danger alert-sm mt-2 mb-2">
                                <small><?php echo $update['error_message']; ?></small>
                            </div>
                            <?php endif; ?>
                            
                            <button class="btn btn-sm btn-<?php echo $type['color']; ?> w-100 mt-2 manual-update-btn" 
                                    data-type="<?php echo $update['update_type']; ?>">
                                <i class="bi bi-play-fill"></i> تشغيل الآن
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">جدول التحديثات التلقائية</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>النوع</th>
                                <th>الفترة الزمنية</th>
                                <th>الوصف</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>مباريات اليوم</td>
                                <td>24 ساعة</td>
                                <td>يتم التحديث مرة واحدة يومياً في الساعة 00:05</td>
                            </tr>
                            <tr>
                                <td>المباريات الجارية</td>
                                <td>25 ثانية</td>
                                <td>تحديث مباشر أثناء المباريات</td>
                            </tr>
                            <tr>
                                <td>الإحصائيات والأحداث</td>
                                <td>50 ثانية</td>
                                <td>يتم التحديث فقط للمباريات الجارية</td>
                            </tr>
                            <tr>
                                <td>التشكيلات</td>
                                <td>30 دقيقة</td>
                                <td>يتم التحميل قبل بداية المباراة</td>
                            </tr>
                            <tr>
                                <td>الترتيب والهدافين</td>
                                <td>ساعتين</td>
                                <td>تحديث دوري للدوريات النشطة</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function checkAllUpdates() {
    if (!confirm('هل تريد تشغيل جميع التحديثات؟')) return;
    
    fetch('ajax/check_updates.php', {method: 'POST'})
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccess('تم تشغيل التحديثات بنجاح');
                setTimeout(() => location.reload(), 2000);
            } else {
                showError(data.message);
            }
        });
}

document.querySelectorAll('.manual-update-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const type = this.dataset.type;
        const btnElement = this;
        
        btnElement.disabled = true;
        btnElement.innerHTML = '<span class="spinner-border spinner-border-sm"></span> جاري...';
        
        fetch('ajax/manual_update.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'type=' + type
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccess(data.message);
                setTimeout(() => location.reload(), 1500);
            } else {
                showError(data.message);
                btnElement.disabled = false;
                btnElement.innerHTML = '<i class="bi bi-play-fill"></i> تشغيل الآن';
            }
        });
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>