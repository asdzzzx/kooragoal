<?php
// إدارة المسؤولين (Super Admin فقط)
// admin/admins.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

if (!isSuperAdmin()) {
    header('Location: index.php');
    exit;
}

$db = Database::getInstance();

// معالجة الإضافة/التعديل
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $username = clean($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $email = clean($_POST['email']);
        $full_name = clean($_POST['full_name']);
        $role = clean($_POST['role']);
        
        $db->insert('admins', [
            'username' => $username,
            'password' => $password,
            'email' => $email,
            'full_name' => $full_name,
            'role' => $role,
            'status' => 'active'
        ]);
        
        $success = 'تم إضافة المسؤول بنجاح';
    }
}

$admins = $db->query("SELECT * FROM admins ORDER BY created_at DESC");

$pageTitle = 'إدارة المسؤولين';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-person-badge"></i> إدارة المسؤولين
                </h1>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAdminModal">
                    <i class="bi bi-plus-circle"></i> إضافة مسؤول
                </button>
            </div>
            
            <?php if (isset($success)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>المستخدم</th>
                                    <th>الاسم الكامل</th>
                                    <th>البريد</th>
                                    <th>الصلاحية</th>
                                    <th>آخر دخول</th>
                                    <th>الحالة</th>
                                    <th>إجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($admins as $admin): ?>
                                <tr>
                                    <td><strong><?php echo $admin['username']; ?></strong></td>
                                    <td><?php echo $admin['full_name']; ?></td>
                                    <td><?php echo $admin['email']; ?></td>
                                    <td>
                                        <span class="badge 
                                            <?php echo $admin['role'] === 'super_admin' ? 'bg-danger' : 
                                                     ($admin['role'] === 'admin' ? 'bg-primary' : 'bg-secondary'); ?>">
                                            <?php 
                                            echo $admin['role'] === 'super_admin' ? 'مدير عام' : 
                                                ($admin['role'] === 'admin' ? 'مسؤول' : 'محرر'); 
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo $admin['last_login'] ? formatDate($admin['last_login']) : 'لم يدخل'; ?>
                                    </td>
                                    <td>
                                        <?php if ($admin['status'] === 'active'): ?>
                                            <span class="badge bg-success">نشط</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">معطل</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($admin['id'] != $_SESSION['admin_id']): ?>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-warning" onclick="toggleStatus(<?php echo $admin['id']; ?>)">
                                                <i class="bi bi-toggle-off"></i>
                                            </button>
                                            <button class="btn btn-danger" onclick="deleteAdmin(<?php echo $admin['id']; ?>)">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                        <?php else: ?>
                                            <span class="text-muted">أنت</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Modal إضافة مسؤول -->
<div class="modal fade" id="addAdminModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة مسؤول جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">اسم المستخدم</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">كلمة المرور</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">البريد الإلكتروني</label>
                        <input type="email" class="form-control" name="email">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">الاسم الكامل</label>
                        <input type="text" class="form-control" name="full_name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">الصلاحية</label>
                        <select class="form-select" name="role" required>
                            <option value="editor">محرر</option>
                            <option value="admin">مسؤول</option>
                            <option value="super_admin">مدير عام</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleStatus(id) {
    fetch('ajax/toggle_admin.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess('تم تغيير الحالة');
            setTimeout(() => location.reload(), 1000);
        }
    });
}

function deleteAdmin(id) {
    if (!confirm('هل تريد حذف هذا المسؤول؟')) return;
    
    fetch('ajax/delete_admin.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess('تم الحذف');
            setTimeout(() => location.reload(), 1000);
        }
    });
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>