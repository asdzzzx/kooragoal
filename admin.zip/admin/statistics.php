<?php
// الإحصائيات
// admin/statistics.php

require_once __DIR__ . '/includes/check_auth.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$stats = [
    'total_leagues' => $db->count('leagues'),
    'total_teams' => $db->count('teams'),
    'total_fixtures' => $db->count('fixtures'),
    'today_fixtures' => $db->count('fixtures', 'DATE(date) = CURDATE()'),
    'live_fixtures' => $db->count('fixtures', 'is_live = 1'),
    'finished_fixtures' => $db->count('fixtures', "status_short IN ('FT', 'AET', 'PEN')"),
    'total_events' => $db->count('events'),
    'total_goals' => $db->count('events', "type = 'Goal'"),
    'total_admins' => $db->count('admins'),
    'total_logs' => $db->count('logs'),
];

$topLeagues = $db->query(
    "SELECT league_name, league_logo, COUNT(*) as count 
     FROM fixtures 
     GROUP BY league_id 
     ORDER BY count DESC 
     LIMIT 10"
);

$recentActivity = $db->query(
    "SELECT * FROM logs ORDER BY created_at DESC LIMIT 20"
);

$pageTitle = 'الإحصائيات';
include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-graph-up"></i> الإحصائيات العامة
                </h1>
            </div>
            
            <div class="row">
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        إجمالي المباريات
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['total_fixtures']); ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-controller" style="font-size: 2rem; color: #4e73df;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        الأهداف المسجلة
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['total_goals']); ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-trophy-fill" style="font-size: 2rem; color: #1cc88a;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-info shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                        الدوريات
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['total_leagues']); ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-trophy" style="font-size: 2rem; color: #36b9cc;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-right-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col me-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                        الفرق
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo number_format($stats['total_teams']); ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-people-fill" style="font-size: 2rem; color: #f6c23e;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h6 class="m-0 font-weight-bold text-primary">أكثر الدوريات نشاطاً</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>الدوري</th>
                                            <th>المباريات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($topLeagues as $league): ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo $league['league_logo']; ?>" width="20" class="me-2" alt="">
                                                <?php echo $league['league_name']; ?>
                                            </td>
                                            <td><strong><?php echo $league['count']; ?></strong></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h6 class="m-0 font-weight-bold text-primary">آخر الأنشطة</h6>
                        </div>
                        <div class="card-body">
                            <div class="list-group list-group-flush">
                                <?php foreach ($recentActivity as $log): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <small><strong><?php echo $log['action_type']; ?></strong></small>
                                        <small class="text-muted"><?php echo formatDate($log['created_at'], 'H:i'); ?></small>
                                    </div>
                                    <small class="text-muted"><?php echo $log['action_description']; ?></small>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
.border-right-primary { border-right: 4px solid #4e73df !important; }
.border-right-success { border-right: 4px solid #1cc88a !important; }
.border-right-info { border-right: 4px solid #36b9cc !important; }
.border-right-warning { border-right: 4px solid #f6c23e !important; }
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>