<?php
// صفحة الفريق - العامة (مصلح)
// public/team.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();
$team_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($team_id <= 0) {
    header('Location: /');
    exit;
}

// جلب معلومات الفريق
$team = $db->queryOne("SELECT * FROM teams WHERE api_id = :id", ['id' => $team_id]);

if (!$team) {
    header('Location: /');
    exit;
}

// جلب آخر المباريات للفريق
$fixtures = $db->query(
    "SELECT * FROM fixtures 
     WHERE home_team_id = :id OR away_team_id = :id 
     ORDER BY date DESC 
     LIMIT 20",
    ['id' => $team_id]
);

// جلب إحصائيات الفريق
$stats = [
    'total_matches' => count($fixtures),
    'wins' => 0,
    'draws' => 0,
    'losses' => 0,
    'goals_for' => 0,
    'goals_against' => 0
];

foreach ($fixtures as $fixture) {
    if ($fixture['status_short'] == 'FT' || $fixture['status_short'] == 'AET' || $fixture['status_short'] == 'PEN') {
        $isHome = ($fixture['home_team_id'] == $team_id);
        $goalsFor = $isHome ? $fixture['goals_home'] : $fixture['goals_away'];
        $goalsAgainst = $isHome ? $fixture['goals_away'] : $fixture['goals_home'];
        
        if ($goalsFor !== null && $goalsAgainst !== null) {
            $stats['goals_for'] += $goalsFor;
            $stats['goals_against'] += $goalsAgainst;
            
            if ($goalsFor > $goalsAgainst) {
                $stats['wins']++;
            } elseif ($goalsFor < $goalsAgainst) {
                $stats['losses']++;
            } else {
                $stats['draws']++;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($team['name']); ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Cairo', sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px 0; }
        .card { border: none; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .team-header { background: white; padding: 40px; text-align: center; border-radius: 15px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; text-align: center; }
        .stat-number { font-size: 2rem; font-weight: bold; color: #667eea; }
        .navbar { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); margin-bottom: 30px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-broadcast" style="font-size: 1.5rem; color: #667eea;"></i>
                <strong style="color: #667eea;"><?php echo SITE_NAME; ?></strong>
            </a>
            <a href="javascript:history.back()" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-arrow-right"></i> رجوع
            </a>
        </div>
    </nav>
    
    <div class="container">
        <!-- معلومات الفريق -->
        <div class="team-header">
            <img src="<?php echo htmlspecialchars($team['logo']); ?>" width="120" class="mb-3" alt="<?php echo htmlspecialchars($team['name']); ?>">
            <h1 class="mb-2"><?php echo htmlspecialchars($team['name']); ?></h1>
            
            <?php if ($team['country']): ?>
            <p class="text-muted mb-2">
                <i class="bi bi-geo-alt-fill"></i> <?php echo htmlspecialchars($team['country']); ?>
            </p>
            <?php endif; ?>
            
            <?php if ($team['founded']): ?>
            <p class="text-muted mb-2">
                <i class="bi bi-calendar-fill"></i> تأسس عام <?php echo htmlspecialchars($team['founded']); ?>
            </p>
            <?php endif; ?>
            
            <?php if ($team['venue_name']): ?>
            <p class="text-muted">
                <i class="bi bi-stadium"></i> الملعب: <?php echo htmlspecialchars($team['venue_name']); ?>
                <?php if ($team['venue_city']): ?>
                    - <?php echo htmlspecialchars($team['venue_city']); ?>
                <?php endif; ?>
                <?php if ($team['venue_capacity']): ?>
                    (السعة: <?php echo number_format($team['venue_capacity']); ?>)
                <?php endif; ?>
            </p>
            <?php endif; ?>
        </div>
        
        <!-- الإحصائيات -->
        <?php if ($stats['total_matches'] > 0): ?>
        <div class="row mb-4">
            <div class="col-md-2 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total_matches']; ?></div>
                    <small class="text-muted">مباريات</small>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="stat-card">
                    <div class="stat-number text-success"><?php echo $stats['wins']; ?></div>
                    <small class="text-muted">فوز</small>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="stat-card">
                    <div class="stat-number text-warning"><?php echo $stats['draws']; ?></div>
                    <small class="text-muted">تعادل</small>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="stat-card">
                    <div class="stat-number text-danger"><?php echo $stats['losses']; ?></div>
                    <small class="text-muted">خسارة</small>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="stat-card">
                    <div class="stat-number text-primary"><?php echo $stats['goals_for']; ?></div>
                    <small class="text-muted">أهداف له</small>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="stat-card">
                    <div class="stat-number text-secondary"><?php echo $stats['goals_against']; ?></div>
                    <small class="text-muted">أهداف عليه</small>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- آخر المباريات -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="bi bi-clock-history"></i> آخر المباريات
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($fixtures)): ?>
                    <div class="alert alert-info text-center">
                        <i class="bi bi-info-circle"></i> لا توجد مباريات مسجلة لهذا الفريق
                    </div>
                <?php else: ?>
                <div class="list-group">
                    <?php foreach ($fixtures as $fixture): ?>
                    <a href="/match/<?php echo $fixture['api_id']; ?>" class="list-group-item list-group-item-action">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <small class="text-muted">
                                    <i class="bi bi-calendar"></i> 
                                    <?php echo date('d/m/Y', strtotime($fixture['date'])); ?>
                                </small>
                                <br>
                                <span class="badge 
                                    <?php 
                                    if (in_array($fixture['status_short'], ['1H', '2H', 'ET'])) {
                                        echo 'bg-danger';
                                    } elseif ($fixture['status_short'] == 'FT') {
                                        echo 'bg-success';
                                    } elseif ($fixture['status_short'] == 'NS') {
                                        echo 'bg-secondary';
                                    } else {
                                        echo 'bg-info';
                                    }
                                    ?>">
                                    <?php echo getMatchStatusAr($fixture['status_short']); ?>
                                </span>
                            </div>
                            
                            <div class="col-md-8">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex align-items-center" style="flex: 1;">
                                        <img src="<?php echo htmlspecialchars($fixture['home_team_logo']); ?>" width="30" class="me-2" alt="">
                                        <span class="<?php echo ($fixture['home_team_id'] == $team_id) ? 'fw-bold' : ''; ?>">
                                            <?php echo htmlspecialchars($fixture['home_team_name']); ?>
                                        </span>
                                    </div>
                                    
                                    <div class="px-3 text-center">
                                        <?php if ($fixture['goals_home'] !== null): ?>
                                            <strong style="font-size: 1.2rem;">
                                                <?php echo $fixture['goals_home']; ?> - <?php echo $fixture['goals_away']; ?>
                                            </strong>
                                        <?php else: ?>
                                            <span class="text-muted">vs</span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="d-flex align-items-center" style="flex: 1; justify-content: flex-end;">
                                        <span class="<?php echo ($fixture['away_team_id'] == $team_id) ? 'fw-bold' : ''; ?>">
                                            <?php echo htmlspecialchars($fixture['away_team_name']); ?>
                                        </span>
                                        <img src="<?php echo htmlspecialchars($fixture['away_team_logo']); ?>" width="30" class="ms-2" alt="">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-2 text-end">
                                <small class="text-muted">
                                    <img src="<?php echo htmlspecialchars($fixture['league_logo']); ?>" width="20" alt="">
                                    <?php echo htmlspecialchars($fixture['league_name']); ?>
                                </small>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>