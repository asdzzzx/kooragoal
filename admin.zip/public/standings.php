<?php
// ============================================
// public/standings.php - ترتيب الدوري
// ============================================
?>
<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
$db = Database::getInstance();
$league_id = $_GET['league_id'] ?? 0;
$season = $_GET['season'] ?? date('Y');
$standings = $db->query("SELECT * FROM standings WHERE league_id = :league_id AND season = :season ORDER BY rank", 
    ['league_id' => $league_id, 'season' => $season]);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الترتيب - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1>ترتيب الدوري</h1>
        <table class="table">
            <thead><tr><th>#</th><th>الفريق</th><th>لعب</th><th>فوز</th><th>تعادل</th><th>خسارة</th><th>النقاط</th></tr></thead>
            <tbody>
                <?php foreach ($standings as $t): ?>
                <tr>
                    <td><?php echo $t['rank']; ?></td>
                    <td><img src="<?php echo $t['team_logo']; ?>" width="25"> <?php echo $t['team_name']; ?></td>
                    <td><?php echo $t['played']; ?></td>
                    <td><?php echo $t['win']; ?></td>
                    <td><?php echo $t['draw']; ?></td>
                    <td><?php echo $t['lose']; ?></td>
                    <td><strong><?php echo $t['points']; ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>