<?php
// ============================================
// public/scorers.php - هدافين الدوري
// ============================================
?>
<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
$db = Database::getInstance();
$league_id = $_GET['league_id'] ?? 0;
$season = $_GET['season'] ?? date('Y');
$scorers = $db->query("SELECT * FROM scorers WHERE league_id = :league_id AND season = :season ORDER BY goals_total DESC LIMIT 50", 
    ['league_id' => $league_id, 'season' => $season]);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الهدافين - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1>قائمة الهدافين</h1>
        <table class="table">
            <thead><tr><th>#</th><th>اللاعب</th><th>الفريق</th><th>الأهداف</th><th>المساعدات</th></tr></thead>
            <tbody>
                <?php foreach ($scorers as $idx => $s): ?>
                <tr>
                    <td><?php echo $idx + 1; ?></td>
                    <td><img src="<?php echo $s['player_photo']; ?>" width="40" class="rounded-circle"> <?php echo $s['player_name']; ?></td>
                    <td><img src="<?php echo $s['team_logo']; ?>" width="25"> <?php echo $s['team_name']; ?></td>
                    <td><strong class="text-success"><?php echo $s['goals_total']; ?></strong></td>
                    <td><?php echo $s['goals_assists']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
