<?php
// ============================================
// public/events.php - أحداث المباراة
// ============================================
?>
<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
$db = Database::getInstance();
$match_id = $_GET['match_id'] ?? 0;
$events = $db->query("SELECT * FROM events WHERE fixture_id = :id ORDER BY time_elapsed", ['id' => $match_id]);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>أحداث المباراة - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <div class="container my-5">
        <h1>أحداث المباراة</h1>
        <div class="list-group">
            <?php foreach ($events as $e): ?>
            <div class="list-group-item">
                <span class="badge bg-secondary"><?php echo $e['time_elapsed']; ?>'</span>
                <img src="<?php echo $e['team_logo']; ?>" width="25">
                <?php if ($e['type'] === 'Goal'): ?>
                    <i class="bi bi-trophy-fill text-success"></i>
                <?php endif; ?>
                <strong><?php echo $e['player_name']; ?></strong> - <?php echo $e['detail']; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>