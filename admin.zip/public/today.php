<?php
// مباريات اليوم - الصفحة العامة
// public/today.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$todayFixtures = $db->query(
    "SELECT * FROM fixtures WHERE DATE(date) = CURDATE() ORDER BY date ASC"
);

$leagues = [];
foreach ($todayFixtures as $fixture) {
    $leagues[$fixture['league_id']]['name'] = $fixture['league_name'];
    $leagues[$fixture['league_id']]['logo'] = $fixture['league_logo'];
    $leagues[$fixture['league_id']]['fixtures'][] = $fixture;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مباريات اليوم - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Cairo', sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .match-card { background: white; border-radius: 10px; padding: 15px; margin-bottom: 15px; 
                      box-shadow: 0 2px 10px rgba(0,0,0,0.1); transition: transform 0.3s; }
        .match-card:hover { transform: translateY(-3px); }
        .navbar { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); }
        .league-header { background: white; border-radius: 10px; padding: 15px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-broadcast" style="font-size: 1.5rem; color: #667eea;"></i>
                <strong style="color: #667eea;"><?php echo SITE_NAME; ?></strong>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/"><i class="bi bi-house-fill"></i> الرئيسية</a></li>
                    <li class="nav-item"><a class="nav-link" href="/live"><i class="bi bi-broadcast"></i> مباشر</a></li>
                    <li class="nav-item"><a class="nav-link active" href="/today"><i class="bi bi-calendar-event"></i> مباريات اليوم</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container my-5">
        <div class="text-center text-white mb-5">
            <h1 class="display-4"><i class="bi bi-calendar-event"></i> مباريات اليوم</h1>
            <p class="lead"><?php echo date('l, d F Y'); ?> - عدد المباريات: <?php echo count($todayFixtures); ?></p>
        </div>
        
        <?php if (empty($todayFixtures)): ?>
            <div class="card text-center p-5">
                <i class="bi bi-calendar-x" style="font-size: 4rem; color: #667eea;"></i>
                <h3 class="mt-4">لا توجد مباريات اليوم</h3>
            </div>
        <?php else: ?>
            <?php foreach ($leagues as $league): ?>
            <div class="league-header">
                <h4 class="mb-0">
                    <img src="<?php echo $league['logo']; ?>" width="30" class="me-2" alt="">
                    <?php echo $league['name']; ?>
                </h4>
            </div>
            
            <div class="row">
                <?php foreach ($league['fixtures'] as $fixture): ?>
                <div class="col-md-6">
                    <div class="match-card">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small class="text-muted"><?php echo date('H:i', strtotime($fixture['date'])); ?></small>
                            <span class="badge 
                                <?php echo in_array($fixture['status_short'], ['1H', '2H']) ? 'bg-danger' : 
                                         ($fixture['status_short'] === 'FT' ? 'bg-success' : 'bg-secondary'); ?>">
                                <?php echo getMatchStatusAr($fixture['status_short']); ?>
                            </span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="text-center" style="flex: 1;">
                                <img src="<?php echo $fixture['home_team_logo']; ?>" width="40" class="mb-2" alt="">
                                <div><small><?php echo $fixture['home_team_name']; ?></small></div>
                            </div>
                            
                            <div class="text-center px-3">
                                <?php if ($fixture['goals_home'] !== null): ?>
                                    <h4 class="mb-0"><?php echo $fixture['goals_home']; ?> - <?php echo $fixture['goals_away']; ?></h4>
                                <?php else: ?>
                                    <h4 class="mb-0 text-muted">vs</h4>
                                <?php endif; ?>
                            </div>
                            
                            <div class="text-center" style="flex: 1;">
                                <img src="<?php echo $fixture['away_team_logo']; ?>" width="40" class="mb-2" alt="">
                                <div><small><?php echo $fixture['away_team_name']; ?></small></div>
                            </div>
                        </div>
                        
                        <div class="text-center mt-2">
                            <a href="/match/<?php echo $fixture['api_id']; ?>" class="btn btn-sm btn-outline-primary">
                                التفاصيل
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>