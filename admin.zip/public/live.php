<?php
// المباريات الجارية - الصفحة العامة
// public/live.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();

$liveFixtures = $db->query(
    "SELECT * FROM fixtures WHERE is_live = 1 ORDER BY date ASC"
);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المباريات الجارية - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Cairo', sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .match-card { background: white; border-radius: 15px; padding: 20px; margin-bottom: 20px; 
                      box-shadow: 0 3px 15px rgba(0,0,0,0.1); transition: transform 0.3s; }
        .match-card:hover { transform: translateY(-5px); }
        .live-badge { background: #dc3545; color: white; padding: 5px 15px; border-radius: 20px; 
                      font-weight: bold; animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
        .navbar { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-broadcast" style="font-size: 1.5rem; color: #667eea;"></i>
                <strong style="color: #667eea;"><?php echo SITE_NAME; ?></strong>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/"><i class="bi bi-house-fill"></i> الرئيسية</a></li>
                    <li class="nav-item"><a class="nav-link active" href="/live"><i class="bi bi-broadcast"></i> مباشر</a></li>
                    <li class="nav-item"><a class="nav-link" href="/today"><i class="bi bi-calendar-event"></i> مباريات اليوم</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container my-5">
        <div class="text-center text-white mb-5">
            <h1 class="display-4"><i class="bi bi-broadcast"></i> المباريات الجارية</h1>
            <p class="lead">تحديث تلقائي كل 30 ثانية</p>
        </div>
        
        <?php if (empty($liveFixtures)): ?>
            <div class="card text-center p-5">
                <i class="bi bi-info-circle" style="font-size: 4rem; color: #667eea;"></i>
                <h3 class="mt-4">لا توجد مباريات جارية حالياً</h3>
                <p class="text-muted">تابع مباريات اليوم أو عد لاحقاً</p>
                <a href="/today" class="btn btn-primary mt-3">مباريات اليوم</a>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($liveFixtures as $fixture): ?>
                <div class="col-md-6 mb-4">
                    <div class="match-card">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <img src="<?php echo $fixture['league_logo']; ?>" width="25" alt="">
                                <small class="ms-2"><?php echo $fixture['league_name']; ?></small>
                            </div>
                            <span class="live-badge">
                                <i class="bi bi-circle-fill"></i> LIVE
                                <?php if ($fixture['status_elapsed']): ?>
                                    - <?php echo $fixture['status_elapsed']; ?>'
                                <?php endif; ?>
                            </span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="text-center" style="flex: 1;">
                                <img src="<?php echo $fixture['home_team_logo']; ?>" width="50" class="mb-2" alt="">
                                <div><strong><?php echo $fixture['home_team_name']; ?></strong></div>
                            </div>
                            
                            <div class="text-center px-4">
                                <h1 class="mb-0 text-primary">
                                    <?php echo $fixture['goals_home'] ?? 0; ?> - <?php echo $fixture['goals_away'] ?? 0; ?>
                                </h1>
                            </div>
                            
                            <div class="text-center" style="flex: 1;">
                                <img src="<?php echo $fixture['away_team_logo']; ?>" width="50" class="mb-2" alt="">
                                <div><strong><?php echo $fixture['away_team_name']; ?></strong></div>
                            </div>
                        </div>
                        
                        <div class="text-center mt-3">
                            <a href="/match/<?php echo $fixture['api_id']; ?>" class="btn btn-sm btn-primary">
                                <i class="bi bi-eye"></i> التفاصيل
                            </a>
                            <a href="/stats/<?php echo $fixture['api_id']; ?>" class="btn btn-sm btn-info">
                                <i class="bi bi-graph-up"></i> الإحصائيات
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        setTimeout(() => location.reload(), 30000);
    </script>
</body>
</html>