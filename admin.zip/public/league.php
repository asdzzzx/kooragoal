<?php
// صفحة الدوري - العامة
// public/league.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();
$league_id = $_GET['id'] ?? 0;

$league = $db->queryOne(
    "SELECT * FROM leagues WHERE api_id = :id ORDER BY season DESC LIMIT 1",
    ['id' => $league_id]
);

if (!$league) { header('Location: /'); exit; }

$fixtures = $db->query(
    "SELECT * FROM fixtures 
     WHERE league_id = :league_id AND league_season = :season 
     ORDER BY date DESC LIMIT 20",
    ['league_id' => $league_id, 'season' => $league['season']]
);

$standings = $db->query(
    "SELECT * FROM standings 
     WHERE league_id = :league_id AND season = :season 
     ORDER BY rank ASC LIMIT 10",
    ['league_id' => $league_id, 'season' => $league['season']]
);

$scorers = $db->query(
    "SELECT * FROM scorers 
     WHERE league_id = :league_id AND season = :season 
     ORDER BY goals_total DESC LIMIT 10",
    ['league_id' => $league_id, 'season' => $league['season']]
);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $league['name']; ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Cairo', sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .card { border: none; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); margin-bottom: 20px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-light bg-white sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-broadcast" style="font-size: 1.5rem; color: #667eea;"></i>
                <strong style="color: #667eea;"><?php echo SITE_NAME; ?></strong>
            </a>
        </div>
    </nav>
    
    <div class="container my-5">
        <div class="card">
            <div class="card-body text-center py-5">
                <img src="<?php echo $league['logo']; ?>" width="100" class="mb-3" alt="">
                <h1><?php echo $league['name']; ?></h1>
                <p class="text-muted">
                    <?php if ($league['country_flag']): ?>
                    <img src="<?php echo $league['country_flag']; ?>" width="25" class="me-2" alt="">
                    <?php endif; ?>
                    <?php echo $league['country']; ?> | موسم <?php echo $league['season']; ?>
                </p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="bi bi-bar-chart"></i> الترتيب</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($standings)): ?>
                            <p class="text-muted text-center">لا توجد بيانات</p>
                        <?php else: ?>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>الفريق</th>
                                    <th>لعب</th>
                                    <th>النقاط</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($standings as $team): ?>
                                <tr>
                                    <td><?php echo $team['rank']; ?></td>
                                    <td>
                                        <img src="<?php echo $team['team_logo']; ?>" width="20" class="me-1" alt="">
                                        <?php echo $team['team_name']; ?>
                                    </td>
                                    <td><?php echo $team['played']; ?></td>
                                    <td><strong><?php echo $team['points']; ?></strong></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <a href="/standings/<?php echo $league_id; ?>" class="btn btn-sm btn-primary w-100">
                            عرض الترتيب الكامل
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0"><i class="bi bi-trophy-fill"></i> الهدافين</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($scorers)): ?>
                            <p class="text-muted text-center">لا توجد بيانات</p>
                        <?php else: ?>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>اللاعب</th>
                                    <th>الفريق</th>
                                    <th>الأهداف</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($scorers as $idx => $scorer): ?>
                                <tr>
                                    <td><?php echo $idx + 1; ?></td>
                                    <td><?php echo $scorer['player_name']; ?></td>
                                    <td>
                                        <img src="<?php echo $scorer['team_logo']; ?>" width="20" alt="">
                                    </td>
                                    <td><strong><?php echo $scorer['goals_total']; ?></strong></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <a href="/scorers/<?php echo $league_id; ?>" class="btn btn-sm btn-warning w-100">
                            عرض جميع الهدافين
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-calendar-event"></i> آخر المباريات</h5>
            </div>
            <div class="card-body">
                <?php if (empty($fixtures)): ?>
                    <p class="text-muted text-center">لا توجد مباريات</p>
                <?php else: ?>
                <div class="list-group">
                    <?php foreach ($fixtures as $fixture): ?>
                    <a href="/match/<?php echo $fixture['api_id']; ?>" class="list-group-item list-group-item-action">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <img src="<?php echo $fixture['home_team_logo']; ?>" width="25" alt="">
                                <?php echo $fixture['home_team_name']; ?>
                            </div>
                            <div>
                                <strong><?php echo $fixture['goals_home'] ?? '-'; ?></strong>
                                -
                                <strong><?php echo $fixture['goals_away'] ?? '-'; ?></strong>
                            </div>
                            <div>
                                <?php echo $fixture['away_team_name']; ?>
                                <img src="<?php echo $fixture['away_team_logo']; ?>" width="25" alt="">
                            </div>
                            <small class="text-muted"><?php echo formatDate($fixture['date'], 'd/m'); ?></small>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>