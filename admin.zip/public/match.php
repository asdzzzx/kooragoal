<?php
// صفحة المباراة - العامة
// public/match.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

$db = Database::getInstance();
$match_id = $_GET['id'] ?? 0;

$fixture = $db->queryOne("SELECT * FROM fixtures WHERE api_id = :id", ['id' => $match_id]);
if (!$fixture) { header('Location: /'); exit; }

$events = $db->query("SELECT * FROM events WHERE fixture_id = :id ORDER BY time_elapsed ASC", ['id' => $match_id]);
$stats = $db->query("SELECT * FROM statistics WHERE fixture_id = :id", ['id' => $match_id]);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $fixture['home_team_name']; ?> vs <?php echo $fixture['away_team_name']; ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Cairo', sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .card { border: none; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .navbar { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); }
        .live-badge { background: #dc3545; animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-broadcast" style="font-size: 1.5rem; color: #667eea;"></i>
                <strong style="color: #667eea;"><?php echo SITE_NAME; ?></strong>
            </a>
        </div>
    </nav>
    
    <div class="container my-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <img src="<?php echo $fixture['league_logo']; ?>" width="25" class="me-2" alt="">
                        <?php echo $fixture['league_name']; ?>
                    </div>
                    <span class="badge <?php echo $fixture['is_live'] ? 'live-badge' : 'bg-light text-dark'; ?>">
                        <?php echo getMatchStatusAr($fixture['status_short']); ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="row align-items-center text-center py-4">
                    <div class="col-md-4">
                        <img src="<?php echo $fixture['home_team_logo']; ?>" width="100" class="mb-3" alt="">
                        <h3><?php echo $fixture['home_team_name']; ?></h3>
                    </div>
                    <div class="col-md-4">
                        <h1 class="display-1 mb-0">
                            <span class="text-primary"><?php echo $fixture['goals_home'] ?? '-'; ?></span>
                            <span class="text-muted">:</span>
                            <span class="text-danger"><?php echo $fixture['goals_away'] ?? '-'; ?></span>
                        </h1>
                        <?php if ($fixture['score_halftime_home'] !== null): ?>
                        <p class="text-muted">الشوط الأول: <?php echo $fixture['score_halftime_home']; ?> - <?php echo $fixture['score_halftime_away']; ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <img src="<?php echo $fixture['away_team_logo']; ?>" width="100" class="mb-3" alt="">
                        <h3><?php echo $fixture['away_team_name']; ?></h3>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if (!empty($events)): ?>
        <div class="card">
            <div class="card-header"><h5 class="mb-0"><i class="bi bi-list-ul"></i> الأحداث</h5></div>
            <div class="card-body">
                <?php foreach ($events as $event): ?>
                <div class="mb-3 pb-3 border-bottom">
                    <span class="badge bg-secondary me-2"><?php echo $event['time_elapsed']; ?>'</span>
                    <img src="<?php echo $event['team_logo']; ?>" width="25" class="me-2" alt="">
                    <?php if ($event['type'] === 'Goal'): ?>
                        <i class="bi bi-trophy-fill text-success fs-4 me-2"></i>
                    <?php endif; ?>
                    <strong><?php echo $event['player_name']; ?></strong>
                    <small class="text-muted">(<?php echo $event['detail']; ?>)</small>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($stats)): ?>
        <div class="card">
            <div class="card-header"><h5 class="mb-0"><i class="bi bi-graph-up"></i> الإحصائيات</h5></div>
            <div class="card-body">
                <?php 
                $home = $stats[0] ?? null;
                $away = $stats[1] ?? null;
                if ($home && $away): ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <strong><?php echo $home['ball_possession']; ?></strong>
                            <span>الاستحواذ</span>
                            <strong><?php echo $away['ball_possession']; ?></strong>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <strong><?php echo $home['shots_on_goal']; ?></strong>
                            <span>التسديدات على المرمى</span>
                            <strong><?php echo $away['shots_on_goal']; ?></strong>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php if ($fixture['is_live']): ?>
    <script>setTimeout(() => location.reload(), 30000);</script>
    <?php endif; ?>
</body>
</html>