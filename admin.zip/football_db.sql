-- قاعدة البيانات الكاملة لنظام كرة القدم
-- yacinetv_football_db

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- جدول المسؤولين
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('super_admin','admin','editor') DEFAULT 'admin',
  `last_login` datetime DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج مسؤول افتراضي (admin / Admin@123)
INSERT INTO `admins` (`username`, `password`, `email`, `full_name`, `role`, `status`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@yacinetv.live', 'المسؤول الرئيسي', 'super_admin', 'active');

-- --------------------------------------------------------
-- جدول الدوريات
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `leagues` (
  `id` int(11) NOT NULL,
  `api_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `logo` varchar(500) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `country_flag` varchar(500) DEFAULT NULL,
  `season` int(11) DEFAULT NULL,
  `season_start` date DEFAULT NULL,
  `season_end` date DEFAULT NULL,
  `is_current` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_id_season` (`api_id`,`season`),
  KEY `idx_country` (`country`),
  KEY `idx_season` (`season`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول الفرق
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `founded` int(11) DEFAULT NULL,
  `national` tinyint(1) DEFAULT 0,
  `logo` varchar(500) DEFAULT NULL,
  `venue_id` int(11) DEFAULT NULL,
  `venue_name` varchar(255) DEFAULT NULL,
  `venue_address` varchar(255) DEFAULT NULL,
  `venue_city` varchar(100) DEFAULT NULL,
  `venue_capacity` int(11) DEFAULT NULL,
  `venue_surface` varchar(50) DEFAULT NULL,
  `venue_image` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_id` (`api_id`),
  KEY `idx_name` (`name`),
  KEY `idx_country` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول اللاعبين
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `birth_place` varchar(255) DEFAULT NULL,
  `birth_country` varchar(100) DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `height` varchar(20) DEFAULT NULL,
  `weight` varchar(20) DEFAULT NULL,
  `photo` varchar(500) DEFAULT NULL,
  `injured` tinyint(1) DEFAULT 0,
  `team_id` int(11) DEFAULT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_id` (`api_id`),
  KEY `idx_team` (`team_id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول المباريات
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `fixtures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_id` int(11) NOT NULL,
  `referee` varchar(255) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT 'UTC',
  `date` datetime NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  `venue_id` int(11) DEFAULT NULL,
  `venue_name` varchar(255) DEFAULT NULL,
  `venue_city` varchar(100) DEFAULT NULL,
  `status_long` varchar(50) DEFAULT NULL,
  `status_short` varchar(10) DEFAULT NULL,
  `status_elapsed` int(11) DEFAULT NULL,
  `league_id` int(11) NOT NULL,
  `league_name` varchar(255) DEFAULT NULL,
  `league_country` varchar(100) DEFAULT NULL,
  `league_logo` varchar(500) DEFAULT NULL,
  `league_flag` varchar(500) DEFAULT NULL,
  `league_season` int(11) DEFAULT NULL,
  `league_round` varchar(100) DEFAULT NULL,
  `home_team_id` int(11) NOT NULL,
  `home_team_name` varchar(255) DEFAULT NULL,
  `home_team_logo` varchar(500) DEFAULT NULL,
  `home_team_winner` tinyint(1) DEFAULT NULL,
  `away_team_id` int(11) NOT NULL,
  `away_team_name` varchar(255) DEFAULT NULL,
  `away_team_logo` varchar(500) DEFAULT NULL,
  `away_team_winner` tinyint(1) DEFAULT NULL,
  `goals_home` int(11) DEFAULT NULL,
  `goals_away` int(11) DEFAULT NULL,
  `score_halftime_home` int(11) DEFAULT NULL,
  `score_halftime_away` int(11) DEFAULT NULL,
  `score_fulltime_home` int(11) DEFAULT NULL,
  `score_fulltime_away` int(11) DEFAULT NULL,
  `score_extratime_home` int(11) DEFAULT NULL,
  `score_extratime_away` int(11) DEFAULT NULL,
  `score_penalty_home` int(11) DEFAULT NULL,
  `score_penalty_away` int(11) DEFAULT NULL,
  `is_live` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_id` (`api_id`),
  KEY `idx_date` (`date`),
  KEY `idx_league` (`league_id`),
  KEY `idx_home_team` (`home_team_id`),
  KEY `idx_away_team` (`away_team_id`),
  KEY `idx_status` (`status_short`),
  KEY `idx_live` (`is_live`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول أحداث المباريات
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fixture_id` int(11) NOT NULL,
  `time_elapsed` int(11) DEFAULT NULL,
  `time_extra` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `team_logo` varchar(500) DEFAULT NULL,
  `player_id` int(11) DEFAULT NULL,
  `player_name` varchar(255) DEFAULT NULL,
  `assist_id` int(11) DEFAULT NULL,
  `assist_name` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `detail` varchar(100) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fixture` (`fixture_id`),
  KEY `idx_team` (`team_id`),
  KEY `idx_player` (`player_id`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول إحصائيات المباريات
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fixture_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `team_logo` varchar(500) DEFAULT NULL,
  `shots_on_goal` int(11) DEFAULT 0,
  `shots_off_goal` int(11) DEFAULT 0,
  `total_shots` int(11) DEFAULT 0,
  `blocked_shots` int(11) DEFAULT 0,
  `shots_inside_box` int(11) DEFAULT 0,
  `shots_outside_box` int(11) DEFAULT 0,
  `fouls` int(11) DEFAULT 0,
  `corner_kicks` int(11) DEFAULT 0,
  `offsides` int(11) DEFAULT 0,
  `ball_possession` varchar(10) DEFAULT '0%',
  `yellow_cards` int(11) DEFAULT 0,
  `red_cards` int(11) DEFAULT 0,
  `goalkeeper_saves` int(11) DEFAULT 0,
  `total_passes` int(11) DEFAULT 0,
  `passes_accurate` int(11) DEFAULT 0,
  `passes_percentage` varchar(10) DEFAULT '0%',
  `expected_goals` varchar(10) DEFAULT '0.0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `fixture_team` (`fixture_id`,`team_id`),
  KEY `idx_fixture` (`fixture_id`),
  KEY `idx_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول التشكيلات
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `lineups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fixture_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `team_logo` varchar(500) DEFAULT NULL,
  `formation` varchar(20) DEFAULT NULL,
  `coach_id` int(11) DEFAULT NULL,
  `coach_name` varchar(255) DEFAULT NULL,
  `coach_photo` varchar(500) DEFAULT NULL,
  `players` longtext DEFAULT NULL,
  `substitutes` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `fixture_team` (`fixture_id`,`team_id`),
  KEY `idx_fixture` (`fixture_id`),
  KEY `idx_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول الترتيب
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `standings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `league_id` int(11) NOT NULL,
  `season` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `team_logo` varchar(500) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT 0,
  `goals_diff` int(11) DEFAULT 0,
  `group` varchar(50) DEFAULT NULL,
  `form` varchar(50) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `played` int(11) DEFAULT 0,
  `win` int(11) DEFAULT 0,
  `draw` int(11) DEFAULT 0,
  `lose` int(11) DEFAULT 0,
  `goals_for` int(11) DEFAULT 0,
  `goals_against` int(11) DEFAULT 0,
  `home_played` int(11) DEFAULT 0,
  `home_win` int(11) DEFAULT 0,
  `home_draw` int(11) DEFAULT 0,
  `home_lose` int(11) DEFAULT 0,
  `home_goals_for` int(11) DEFAULT 0,
  `home_goals_against` int(11) DEFAULT 0,
  `away_played` int(11) DEFAULT 0,
  `away_win` int(11) DEFAULT 0,
  `away_draw` int(11) DEFAULT 0,
  `away_lose` int(11) DEFAULT 0,
  `away_goals_for` int(11) DEFAULT 0,
  `away_goals_against` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `league_season_team` (`league_id`,`season`,`team_id`),
  KEY `idx_league` (`league_id`),
  KEY `idx_season` (`season`),
  KEY `idx_team` (`team_id`),
  KEY `idx_rank` (`rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول الهدافين
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `scorers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `league_id` int(11) NOT NULL,
  `season` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `player_name` varchar(255) DEFAULT NULL,
  `player_photo` varchar(500) DEFAULT NULL,
  `player_age` int(11) DEFAULT NULL,
  `player_nationality` varchar(100) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `team_logo` varchar(500) DEFAULT NULL,
  `games_appearances` int(11) DEFAULT 0,
  `games_minutes` int(11) DEFAULT 0,
  `games_position` varchar(50) DEFAULT NULL,
  `games_rating` varchar(10) DEFAULT NULL,
  `goals_total` int(11) DEFAULT 0,
  `goals_assists` int(11) DEFAULT 0,
  `goals_saves` int(11) DEFAULT NULL,
  `shots_total` int(11) DEFAULT 0,
  `shots_on` int(11) DEFAULT 0,
  `passes_total` int(11) DEFAULT 0,
  `passes_accuracy` int(11) DEFAULT 0,
  `penalties_scored` int(11) DEFAULT 0,
  `penalties_missed` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `league_season_player` (`league_id`,`season`,`player_id`),
  KEY `idx_league` (`league_id`),
  KEY `idx_season` (`season`),
  KEY `idx_player` (`player_id`),
  KEY `idx_goals` (`goals_total`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول تحديثات النظام
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `system_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `update_type` varchar(50) NOT NULL,
  `last_update` datetime NOT NULL,
  `next_update` datetime DEFAULT NULL,
  `update_interval` int(11) DEFAULT NULL COMMENT 'بالثواني',
  `status` enum('success','failed','running') DEFAULT 'success',
  `records_count` int(11) DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `update_type` (`update_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج أنواع التحديثات الافتراضية
INSERT INTO `system_updates` (`update_type`, `last_update`, `update_interval`, `status`) VALUES
('daily_fixtures', '2020-01-01 00:00:00', 86400, 'success'),
('live_fixtures', '2020-01-01 00:00:00', 25, 'success'),
('fixtures_statistics', '2020-01-01 00:00:00', 50, 'success'),
('fixtures_events', '2020-01-01 00:00:00', 50, 'success'),
('fixtures_lineups', '2020-01-01 00:00:00', 1800, 'success'),
('leagues_standings', '2020-01-01 00:00:00', 7200, 'success'),
('leagues_scorers', '2020-01-01 00:00:00', 7200, 'success'),
('teams_data', '2020-01-01 00:00:00', 2592000, 'success'),
('players_data', '2020-01-01 00:00:00', 2592000, 'success');

-- --------------------------------------------------------
-- جدول السجلات
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  `action_description` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `status` enum('success','failed','warning') DEFAULT 'success',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin` (`admin_id`),
  KEY `idx_type` (`action_type`),
  KEY `idx_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- جدول الدوريات المفضلة للسحب التلقائي
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `favorite_leagues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `league_id` int(11) NOT NULL,
  `league_name` varchar(255) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `priority` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `league_id` (`league_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج الدوريات الرئيسية
INSERT INTO `favorite_leagues` (`league_id`, `league_name`, `country`, `priority`) VALUES
(39, 'Premier League', 'England', 1),
(140, 'La Liga', 'Spain', 2),
(135, 'Serie A', 'Italy', 3),
(78, 'Bundesliga', 'Germany', 4),
(61, 'Ligue 1', 'France', 5),
(2, 'UEFA Champions League', 'World', 6),
(3, 'UEFA Europa League', 'World', 7),
(1, 'World Cup', 'World', 8),
(4, 'Euro Championship', 'Europe', 9),
(28, 'Copa America', 'South America', 10);

COMMIT;