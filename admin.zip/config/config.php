<?php
// ملف الإعدادات الرئيسي
// config/config.php

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'yacinetv_football_db');
define('DB_USER', 'yacinetv_football_db');
define('DB_PASS', '01010250185!!');
define('DB_CHARSET', 'utf8mb4');

// إعدادات API-FOOTBALL
define('API_KEY', 'eee60a0a491976182f656c6e4e7d1a25');
define('API_BASE_URL', 'https://v3.football.api-sports.io');
define('API_HOST', 'v3.football.api-sports.io');

// إعدادات الموقع
define('SITE_URL', 'https://yacine--tv.live');
define('SITE_NAME', 'Yacine TV Football');
define('ADMIN_PATH', '/admin');

// إعدادات الأمان
define('SESSION_LIFETIME', 3600); // ساعة واحدة
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCK_TIME', 900); // 15 دقيقة
define('PASSWORD_MIN_LENGTH', 6);

// إعدادات النظام
define('TIMEZONE', 'Africa/Cairo');
define('DATE_FORMAT', 'Y-m-d H:i:s');
define('ITEMS_PER_PAGE', 20);

// إعدادات التحديثات التلقائية (بالثواني)
define('UPDATE_INTERVAL_DAILY_FIXTURES', 86400);     // 24 ساعة
define('UPDATE_INTERVAL_LIVE_FIXTURES', 25);         // 25 ثانية
define('UPDATE_INTERVAL_STATISTICS', 50);            // 50 ثانية
define('UPDATE_INTERVAL_EVENTS', 50);                // 50 ثانية
define('UPDATE_INTERVAL_LINEUPS', 1800);             // 30 دقيقة
define('UPDATE_INTERVAL_STANDINGS', 7200);           // ساعتين
define('UPDATE_INTERVAL_SCORERS', 7200);             // ساعتين
define('UPDATE_INTERVAL_TEAMS', 2592000);            // شهر
define('UPDATE_INTERVAL_PLAYERS', 2592000);          // شهر

// تفعيل عرض الأخطاء (للتطوير فقط - أوقفه في الإنتاج)
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// إعداد المنطقة الزمنية
date_default_timezone_set(TIMEZONE);

// بدء الجلسة إذا لم تكن بدأت
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// دالة للتحقق من تسجيل الدخول
function isLoggedIn() {
    return isset($_SESSION['admin_id']) && isset($_SESSION['admin_username']);
}

// دالة للتحقق من صلاحية Super Admin
function isSuperAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'super_admin';
}

// دالة لإعادة التوجيه
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// دالة للحصول على IP العميل
function getClientIP() {
    $ip = '';
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// دالة تنظيف المدخلات
function clean($data) {
    if (is_array($data)) {
        return array_map('clean', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// دالة تحويل التاريخ
function formatDate($date, $format = 'Y-m-d H:i') {
    if (empty($date)) return '-';
    return date($format, strtotime($date));
}

// دالة للحصول على حالة المباراة بالعربي
function getMatchStatusAr($status) {
    $statuses = [
        'TBD' => 'لم تحدد',
        'NS' => 'لم تبدأ',
        '1H' => 'الشوط الأول',
        'HT' => 'استراحة',
        '2H' => 'الشوط الثاني',
        'ET' => 'وقت إضافي',
        'P' => 'ركلات ترجيح',
        'FT' => 'انتهت',
        'AET' => 'انتهت بوقت إضافي',
        'PEN' => 'انتهت بركلات ترجيح',
        'BT' => 'استراحة',
        'SUSP' => 'معلقة',
        'INT' => 'متوقفة',
        'PST' => 'مؤجلة',
        'CANC' => 'ملغاة',
        'ABD' => 'متروكة',
        'AWD' => 'بقرار تقني',
        'WO' => 'بالانسحاب',
        'LIVE' => 'مباشر'
    ];
    return $statuses[$status] ?? $status;
}

// دالة JSON Response
function jsonResponse($success, $message = '', $data = []) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit();
}