<?php
// كلاس قاعدة البيانات
// config/Database.php

class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];
            
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die("خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    // منع استنساخ الكائن
    private function __clone() {}
    
    // منع إلغاء التسلسل
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
    
    // تنفيذ استعلام SELECT
    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            $this->logError($e->getMessage(), $sql);
            return false;
        }
    }
    
    // تنفيذ استعلام SELECT وإرجاع صف واحد
    public function queryOne($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch();
        } catch (PDOException $e) {
            $this->logError($e->getMessage(), $sql);
            return false;
        }
    }
    
    // تنفيذ استعلام INSERT/UPDATE/DELETE
    public function execute($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            $this->logError($e->getMessage(), $sql);
            return false;
        }
    }
    
    // الحصول على آخر ID مُدرج
    public function lastInsertId() {
        return $this->connection->lastInsertId();
    }
    
    // إدراج بيانات
    public function insert($table, $data) {
        $fields = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        
        $sql = "INSERT INTO {$table} ({$fields}) VALUES ({$placeholders})";
        
        if ($this->execute($sql, $data)) {
            return $this->lastInsertId();
        }
        return false;
    }
    
    // تحديث بيانات
    public function update($table, $data, $where, $whereParams = []) {
        $fields = [];
        foreach (array_keys($data) as $key) {
            $fields[] = "{$key} = :{$key}";
        }
        $fields = implode(', ', $fields);
        
        $sql = "UPDATE {$table} SET {$fields} WHERE {$where}";
        
        $params = array_merge($data, $whereParams);
        return $this->execute($sql, $params);
    }
    
    // حذف بيانات
    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        return $this->execute($sql, $params);
    }
    
    // عد الصفوف
    public function count($table, $where = '', $params = []) {
        $sql = "SELECT COUNT(*) as total FROM {$table}";
        if ($where) {
            $sql .= " WHERE {$where}";
        }
        
        $result = $this->queryOne($sql, $params);
        return $result ? (int)$result['total'] : 0;
    }
    
    // التحقق من وجود سجل
    public function exists($table, $where, $params = []) {
        return $this->count($table, $where, $params) > 0;
    }
    
    // بدء معاملة
    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }
    
    // تأكيد المعاملة
    public function commit() {
        return $this->connection->commit();
    }
    
    // إلغاء المعاملة
    public function rollback() {
        return $this->connection->rollback();
    }
    
    // تسجيل الأخطاء
    private function logError($error, $sql) {
        $logFile = __DIR__ . '/../logs/database_errors.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $message = date('Y-m-d H:i:s') . " - Error: {$error}\nSQL: {$sql}\n\n";
        file_put_contents($logFile, $message, FILE_APPEND);
    }
    
    // تنظيف الجداول القديمة
    public function cleanOldData($days = 30) {
        $date = date('Y-m-d', strtotime("-{$days} days"));
        
        // حذف المباريات القديمة المنتهية
        $this->execute(
            "DELETE FROM fixtures WHERE date < :date AND status_short IN ('FT', 'AET', 'PEN', 'CANC', 'ABD', 'PST')",
            ['date' => $date]
        );
        
        // حذف السجلات القديمة
        $this->execute(
            "DELETE FROM logs WHERE created_at < :date",
            ['date' => $date]
        );
        
        return true;
    }
}